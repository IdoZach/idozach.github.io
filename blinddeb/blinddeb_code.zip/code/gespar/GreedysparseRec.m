function [fMin,x_n,Tind] = GreedysparseRec(c,k,measurementSet,n,Tind,maxT,sup_inds)
%GreedysparseRec Finds a k sparse solution x to c=|Fx|^2, for 2D signals
verbose=0;
if exist('sup_inds','var')
    p = sup_inds;
    idx = randperm(length(p));
    p = p(idx);
else
    p=randperm(n);
end
supp=p(1:k);
iterations=1000; % GN iterations
iterations=30; % PGM - GN iterations
c=c(measurementSet);
w=(1+(rand(length(measurementSet),1)<0.5))'; % Use random weights
%w=w*0+1; %%% 
% ido - use a more practical initial guess
initial_guess = mat2gray(1+0*randn(k,1)); initial_guess=initial_guess/sum(initial_guess);
% initial_guess = randn(k,1)+1i*rand(k,1); % original
%[x_k,iterationEr] = GN   (supp,c,n,initial_guess,iterations,w); % Initial guess - Gauss Newton
[x_k,iterationEr] =GN_PGM(supp,c,n,initial_guess,iterations,w); % ido
%plot(iterationEr,'.-'),input('')
fMin=PGM_cost(c,x_k,w);
it=0;
while(1)
    it=it+1;
    %% Main iteration
    [junk,idx]=sort(abs(x_k(supp)));
    supp=supp(idx); % Sorting supp from min(abs(x_k)) to max
    fGrad=WGf_QU_G_Gradient(c,x_k);
    %fGrad = PGM_grad(c,x_k);
    %offSupp=setdiff(1:n,supp); % original impmenentation
    offSupp=setdiff(sup_inds,supp); % using limited support
    
    [junk,idx]=sort(-abs(fGrad(offSupp)));
    offSupp=offSupp(idx);
    pSupp=1:length(supp);
    
    pOffSupp=1:length(offSupp);
    improved=0;
    if numel(offSupp)>0
        for iInd=1:length(supp)
            i=supp(pSupp(iInd)); %Index to remove
            for jInd=1:min(1,length(pOffSupp))     % this is mostly empty, why?
                j=offSupp(pOffSupp(jInd)); % Index to insert
                %% Check replacement
                suppTemp=supp;
                suppTemp((suppTemp==i))=j;
                %{
                % check the support is indeed within the top-left compact
                % supported rectangle fitting the filter
                sup1 = zeros(sqrt(n));
                sup1(suppTemp)=1;
                imagesc(sup1), drawnow
                %}
                
                Tind=Tind+1;
                %% Solve GN with given support
                %xTemp=GN(suppTemp,c,n,x_k(suppTemp),iterations,w);
                
                [xTemp,costfun]=GN_PGM(suppTemp,c,n,x_k(suppTemp),iterations,w); % ido
                %plot(costfun,'.-'),drawnow%,input('')
                fTemp=PGM_cost(c,xTemp,w);
                if fTemp<fMin
                    if (verbose)
                        fprintf('it: %d, T: %d, Replaced %d with %d   f= %3.3f\n',it, Tind,i,j,fTemp);
                    end  
                    x_k=xTemp;
                    x_n=x_k;
                     %{
                    imagesc(reshape(x_n,sqrt(n),[])),drawnow
                    %}
                    supp=suppTemp;
                    improved=1;  
                    fMin=fTemp;
                    if fTemp<1e-3
                        if (verbose) fprintf('******************************************Success!, iteration=%d\n',it);end
                        return;
                    end

                    break;
                end
            end
            if (improved) 
                break;
            end
        end
    end
        if (~improved || Tind>maxT)
            if (verbose)
                fprintf('no possible improvement - trying new initial guess\n');
            end
            x_n=x_k;
            return                
        end
end
x_n=x_k;
end

