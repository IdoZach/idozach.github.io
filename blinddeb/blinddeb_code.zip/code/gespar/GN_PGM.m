function [x,errVec]=GN_PGM(S,c,n,x0,iterations,w)
    x=zeros(n,1);
    x(S)=x0;
    %s=0.5;
    %W=dftmtx(sqrt(n));
    %ind=0;
    %%% Building MM matrix on the fly
    %MM - partial fft matrix operator for vectorized images,
    % calculated only for items in the support
    tol=1e-4; % orig
    tol=1e-3; % orig
    %{
    for indS=S
        alpha=ceil(indS/sqrt(n));
        beta=mod(indS,sqrt(n));
        if (beta==0)
            beta=sqrt(n);
        end
        ind=ind+1;
        MM(:,ind)=kron(W(:,alpha),W(:,beta));
    end
    %}
    %%% ido - projected gradient method with line search (PGM)
    alpha=0.5; beta=1.25; t=1; % PGM
    %%% GN
    for i=1:iterations
        t = beta*t; % PGM
        %s=min([2*s,1]);
        %z=fft2(reshape(x,sqrt(n),sqrt(n)));
        %z=z(:);
        %XM=w.*(z');
        %B=bsxfun(@times,real(z).*sqrt(w'),real(MM))+bsxfun(@times,imag(z).*sqrt(w'),imag(MM));
        %b=sqrt(w').*(c+abs(z).^2);
        xold=x;

        % PGM
        %fold=WG_cost(c,xold,w);
        fold=PGM_cost(c,xold,w);
        
        xold=real(xold);
        %c
        it=0;
		cur_grad = PGM_grad(c,x);
        while 1
            it=it+1;
            newx = PGM_project(xold-t*cur_grad);
            cur_cost = PGM_cost(c,newx,w);
            diff1 = newx - xold;
            %interp_cost = PGM_cost(c,newx,w) + cur_grad(:)'*diff1(:) + sum(diff1.^2)/2/t;
            interp_cost = fold + cur_grad(:)'*diff1(:) + sum(diff1.^2)/2/t;
            %[t cur_cost interp_cost]
            if cur_cost <= interp_cost
                break
            end
            t = alpha*t;
        end
        %cur_cost
        x=newx;

        %

        % prev
        %{
        fold=WG_cost(c,xold,w);
        x=zeros(n,1);
        x(S)=2*B\b;
        xnew=x;
        while((WG_cost(c,xold+s*(xnew-xold),w)>fold))% && (s>1e-5))
            s=0.5*s;
        end
        x=xold+s*(xnew-xold);
        %}
        %

        errVec(i)=fold;
        if (norm(x-xold)<tol)
            %fprintf('breaking\n')
            return
        end
    end
end