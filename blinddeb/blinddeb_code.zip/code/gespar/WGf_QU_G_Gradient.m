function out=WGf_QU_G_Gradient(c,x)
% Returns gradient of cost function around current estimate x
[m,n]=size(x);
z=fft2(reshape(x,sqrt(m),sqrt(m)));
c=reshape(c,sqrt(m),sqrt(m));
out=ifft2((abs(z).^2-c).*z);
out=out(:);
end

