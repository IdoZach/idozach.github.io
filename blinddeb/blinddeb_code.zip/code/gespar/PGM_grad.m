function out = PGM_grad(c,x)
%x_im = reshape(x,sqrt(numel(x)),[]);
%c_im = reshape(c,sqrt(numel(x)),[]);
%h_i = abs(fft2(x_im)).^2 - c_im;
%h_i = h_i(:);

[m,n]=size(x);
z=fft2(reshape(x,sqrt(m),sqrt(m)));
c=reshape(c,sqrt(m),sqrt(m));
out=ifft2((abs(z).^2-c).*z);
out=out(:);
out = real(out);

end