% project the vector b onto the probability simplex
% i.e. b>0 and sum(b)=1
% based on Wang2013

function b_out = PGM_project(b)
is_vertical = isequal(size(b),size(b(:)));

b=b(:);
[b_sorted,~] = sort(b,'descend');
v = 1:numel(b);
term = b_sorted + 1./v(:).*(1-cumsum(b_sorted));
rho = find(term>0,1,'last');
lambda = 1/rho*(1-sum(b_sorted(1:rho)));
b_out = max(0, b+lambda);
if ~is_vertical
    b_out=b_out';
end
end