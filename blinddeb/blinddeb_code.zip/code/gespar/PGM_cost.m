function out = PGM_cost(c,x,w)

% Returns the squared 2 norm of the consistency error 
[m,n]=size(x);
x=reshape(x,sqrt(m),sqrt(m));

% blur filter constraints
%x(x<0.01)=0; x=x/sum(x(:)); % ido

y=abs(fft2(x)).^2;
out=sqrt(sum(w'.*((y(:)-c).^2)));

out=real(out);

end