function res = GESPAR_phase_retrieval(mag2, sparsity_index, n_out, disp)
% This scripts performs a 2D Fourier GESPAR recovery example.
% It generates a random real matrix and tries to recover it from its (possibly noisy) 2D Fourier magnitude measurements. 
% 
% Important parameters:

% mag2 - unshifted magnitude squared.

% n= number of measurements.  The size of the matrix is sqrt(n) by sqrt(n)
% kVec = simulated sparsity level
% maxT = Number of replacements allowed per signal
% snr = noise added to measurements.  
if ~exist('sparsity_index','var')
    sparsity_index = 20;
end
if ~exist('disp','var')
    disp = false;
end
%close all;
%clear;
% prepare a support for a kernel that has a smaller support than the
% magnitude dimension:
vx = repmat(1:n_out,1,n_out);
vy = kron(1:n_out,ones(1,n_out));
sup_inds = sub2ind(size(mag2),vx,vy);

%s = RandStream('mcg16807','Seed',0); % Seeding random number generation
%RandStream.setGlobalStream(s);
n=numel(mag2);%n_out^2; % size of x
m=n; % number of measurement vectors
snr=inf; 
maxIt=1000;
maxT=6400; % Total number of replacements
display=1;
kind=0;
k=sparsity_index; % Sparsity (number of nonzeros in x)
itsPer_kMax=1;
tic
%x=zeros(n,1); 
locs=randperm(n);
%x(locs(1:k))=(1+rand(k,1)).*(-1).^randi(2,[k,1]);% signal vector
%b0_pad = padarray(b0, sqrt([n n])-size(b0), 'post');
%x = b0_pad; imresize(b0_pad,[sqrt(n),sqrt(n)]);  
%x = x(:);
%c=abs(fft2(reshape(x,sqrt(n),sqrt(n)))).^2;% ideal measurements
c = mag2;
c=awgn(c(:),snr,'measured'); % noisy measurements
measurementSet=1:m; % Set of measurements (rows in M) used. 1:m uses all measurements 
fMin=inf;
xBest=zeros(size(mag2));
Tind=0;
tol=1e5;
%tol=1e3;
maxT2 = 50;
%maxT2 = maxT;%5;
%maxT = 100; % inner iterations/replacements
while Tind<=maxT2
    [fVal,x_n,Tind]=GreedysparseRec(c,k,measurementSet,n,Tind,maxT,sup_inds);
    if fVal<fMin
        fMin=fVal;
        xBest=x_n;
        %xBestFlipped=bestMatch2D(xBest,x);
        if fMin<norm(c)/tol
                break;
        end
    end    
end
%err=1-abs(x'*xBestFlipped(:)/(norm(x)*norm(xBestFlipped(:))));
%fprintf('Error =%d\n',err);
%xBestFlipped=xBestFlipped(:);
fprintf('finished one GESPAR\n');
%t=toc;
res = real(reshape(xBest,sqrt([n n])));
%rp=regionprops(res>0.01,'boundingbox');
%cropped = imcrop(res,rp.BoundingBox);
%cropped = padarray(cropped,n_out*[1 1]-size(cropped),'post');
%cropped = cropped(1:n_out,1:n_out);
%res=cropped;
res = res(1:n_out,1:n_out);

% just in case
res(res<0.0)=0;
res=res/sum(res(:));

%res = mat2gray(res);
%res = res/sum(res(:));
if disp
    figure;subplot(2,2,3);stem(1:n,real(x),'--o');hold all;subplot(2,2,[3:4]);plot(1:n,real(xBestFlipped),'rx');
    xlabel('index');ylabel('value');xlim([0 n]);title('True/Recovered (column stacked)');legend('True signal','Recovered');
    subplot(2,2,1);imagesc(reshape(c/max(c),sqrt(n),sqrt(n)));colorbar;title('Measurements (Fourier magnitude)');colormap(bone);subplot(2,2,2);imagesc(reshape(x,sqrt(n),sqrt(n)));colormap(bone);title('True signal');colorbar;
    subplot(224); imagesc(res)
    colorbar 
end