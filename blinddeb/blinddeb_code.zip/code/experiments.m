% here we perform comparisons of blind deblurring with original fattal's
% dataset. 

% run on PC, Fattal's original algorithm uses codes compiled for Windows
% only.

% % % % % % % % % % 
% 1: load images  %
% % % % % % % % % %
%addpath('./bfilter2/');
%addpath('./spgl1-1.9/'); % bpdn algorithm
%addpath('./tvbd_cvpr14/lib/');
%addpath('./blind_diff/')
%addpath(genpath('./BlindDeconvCode')) % irani
addpath(genpath('./FattalDeblur')) % fattal, modified by me
FATTAL_IMG = fullfile(getenv('USERPROFILE'),'Documents\MATLAB','texture1.png');
%addpath(genpath('./BlindDeblurring_MichaeliIrani_v1'));
%addpath('C:\Users\ido\Dropbox\Grad\competing_papers\BM3Dv2\BM3D\');
%addpath('C:\Users\ido\Dropbox\Grad\yyz\FracLab\Gui');
%flpath
%addpath('../wavelet_matrix_operators/')
%addpath('../wavelet_matrix_operators/matlabPyrTools/')
addpath('./gespar/')    
%addpath('./epll/');
%addpath('../decomposing_fbm2/testnlm/');
%cd 'spgl1-1.9'
%spgsetup

%%% natural image
P = 4; % P=4 works for demonstration purposes
P = 8; % for extracting lines
dd=2; % skip between patches
N=256;

%% process raw texture images from directory and put in a directory ready for processing

% raw directory should contain "im*.png" image files and "K*.png" kernel
% files.

raw_path = './textures/';
tar_path = './results/';
mkdir(tar_path);

% process kernels
files = dir(raw_path);
files = files(3:end);
kernels = {};
imgs = {}; k_num = 0; im_num = 0;
N=256;
src = struct;
for i=1:length(files)
    fname = files(i).name;
    if fname(1)=='K' % kernel
        k_num = k_num+1;
        ker = mat2gray(imread([raw_path fname]));
        %ker = imresize(ker,[11 11]);
        %ker = max(0,ker);
        imwrite(mat2gray(ker),[tar_path 'K' num2str(k_num) '.png']);
        src.kernel{k_num} = [tar_path 'K' num2str(k_num) '.png'];
        imagesc(ker),input('')
    else % img
        im_num = im_num+1;
        im = imread([raw_path fname]);
        if size(im,3)>1
            im = rgb2gray(im);
        end
        im = imresize(im,[N N]);
        %im = im(1:N,1:N);
        imwrite(mat2gray(im),[tar_path 'im' num2str(im_num) '.png']);
        src.orig{im_num} = [tar_path 'im' num2str(im_num) '.png'];
    end
end
% produce experiments from imgs x kernels
exps = struct('orig',[],'kernel',[],'deg',[]);
e = 0;
for k=1:k_num
    for i=1:im_num
        e = e + 1;
        exps(e).orig = mat2gray(imread(src.orig{i}));
        exps(e).kernel = mat2gray(imread(src.kernel{k}));
        exps(e).kernel = exps(e).kernel / sum(exps(e).kernel(:));
        exps(e).deg = imfilter(exps(e).orig,exps(e).kernel,'replicate','conv');
    end
end
fprintf('total exps: %d\n', length(exps))
%%

% blind deblurring trials % 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% define experiments (image and blur types)

if ~exist('myresults','var')
    myresults=struct('est_ker',{},'res',{},'x',{},'y',{},'b0',{},'y_epll',{},'best_res',{});
end

coef=1; disp=0; filtsz=8;
orig_d = [3 -32 168 -672 0 672 -168 32 -3]/840;
[d, h] = hp_filter_design(filtsz, N, 2, disp);
%d = orig_d;
L = abs(fft(conv(d,d(end:-1:1)))).^2;
save('custom_d_filt.mat','d');
border=12;
noise_std0=0;
%% possibly load previous results
%load('exps_v_sota.mat','res_iters_exp','res_fattal','res_exp')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% perform ALL experiments
do_all_exps = false;
do_all_exps = true;

if do_all_exps
    % many experiments
    exps_v = 1:length(exps);
    iters = 10; % iterations ber r^2 and exp (i.e. number of random initialization)
    r2_thres_v = [0.8 0.9 1.0];
else
    % one experiment
    exps_v = 4;
    iters = 10; % iterations ber r^2 and exp (i.e. number of random initialization)
    r2_thres_v = [0.8];
end

if ~exist('res_exp','var') || ~do_all_exps
    res_exp = cell(1,length(exps_v));
    res_fattal = cell(1,length(exps_v));
    res_iters_exp = cell(1,length(exps_v));
end
%addpath('./FattalDeblur/NonBlindDeconvolution');
%addpath('./FattalDeblur/');

for ii = 1:length(exps_v) % chg to 1
    if ~isempty(res_exp{ii})
        % already done before.
        fprintf('already done exp %d\n',ii);
        continue
    end
    cur_exp = exps_v(ii);
%% load experiment
    %cur_exp = 2;
    
    x = exps(ii).orig;
    y = exps(ii).deg;
    b0 = exps(ii).kernel;
    %[y,x,b0] = load_exp_fattal_excerpt(src,exps_v(ii));
    
    subplot(331); imshow(x,[]); title(sprintf('exp %d: x',cur_exp));
    subplot(332); imshow(b0,[]); title('b');
    subplot(333); maketitle('y',x,y); 
    drawnow

    %% test fattal v. my own with various R^2 values

    imwrite(mat2gray(min(1,max(0,y))),FATTAL_IMG)
    close all

    % perform fattal orig
    cd FattalDeblur/
    addpath('..')
    
    fprintf('performing original fattal\n');
    [orig_fattal_kernel, orig_fattal_img] = demo(8,struct('impath',FATTAL_IMG,'use',0,'r2_thres',1,'use_fractal_score',0,'use_my_phaseret',0));
    
    cd ..
    best_circshifted = find_best_circshift(x,orig_fattal_img);
    ps_ext = maketitle_d('rec fattal',x,best_circshifted,border,disp);
    res_fattal{ii} = {orig_fattal_kernel, best_circshifted, ps_ext};
    % end fattal orig
    
    %% do my deblurring
    disp=0;


    dd=20;
    t_all = tic;
    res_iters_rr = cell(1,length(r2_thres_v));
    %r2_thres_v = 0.7 ; % just one
    best_ssim_v = r2_thres_v * 0;
    PS_rr = cell(1,length(r2_thres_v));
    best_res_byfractal = cell(1,length(r2_thres_v));
    best_res_byssim = cell(1,length(r2_thres_v));
    for rr = 1:length(r2_thres_v)
        PS_v = zeros(iters,3); % psnr, ssim, fractal score
        best_fracscore = 0;
        best_ssim = 0;
        res_iters = cell(1,iters);

        r2_thres = r2_thres_v(rr);
        fprintf('==-=-=-=-=-=-=-=- R2 THRES: %1.2f =-=-=-=-=-=\n', r2_thres);

        myopts = struct('use',true,'r2_thres',r2_thres); % threshold for whitening filter in calcACProjection function
        myopts.use_fractal_score = false;
        myopts.use_my_phaseret = true;
        myopts.impath = FATTAL_IMG;
        t_iters = tic;
        for i=1:iters
            fprintf('=== EXP done: %1.2f, R2 done: %1.2f, inner iteration: %1.2f ===\n',...
                    ii/length(exps_v), rr/length(r2_thres_v), i/iters)
            close all
            cd FattalDeblur/
            
            [our_kernel, our_img] = demo(8,myopts);
            % perform fattal experiment
            cd ..
            %est_img = min(1,max(0,fattal_img));
            est_img = our_img;
            best_circshifted = find_best_circshift(x,est_img);
            ps = maketitle_d('rec fattal',x,best_circshifted,border,disp);
            res_iters{i} = {our_kernel, our_img};

            
            img = mat2gray(max(0,min(1,y(dd:end-dd+1,dd:end-dd))));
            [fracscore, bestWindow] = calcScoreDeconvWindow(our_kernel, img, false);
            % here ps is calculated with the best circshifted, and fracscore is
            % calculated from the resulting image itself (i.e. without cheating)
            PS_v(i,:) = [ps.P; ps.S; fracscore];
            if fracscore > best_fracscore
                best_fracscore = fracscore;
                best_kernel = our_kernel;
                best_img = our_img;
            end
            if ps.S > best_ssim
                best_ssim = ps.S;
                best_kernel_byssim = our_kernel;
                best_img_byssim = our_img;
            end
        end
        time_iters = toc(t_iters);
        time_iters
        means = mean(PS_v,1);
        stds = std(PS_v,1);
        figure(3);
        set(gcf,'position',[50 25 600 750]);
        border=12;
        subplot(421); imshow(x,[]); title('deblur by orig kernel')
        if all ( (size(best_kernel_byssim)-size(b0) > 0 ) )
            subplot(422); imshow(padarray(b0,round(0.5*(size(best_kernel_byssim)-size(b0))),'both'),[]);
        else
            subplot(422); imshow(b0,[]);
        end
        title('gt kernel')
        subplot(423); maketitle_d('blurred',x,y,border);
        
        best_circshift = find_best_circshift(x,best_img_byssim);
        subplot(425); maketitle_d('rec my',x,best_circshift,border);
        subplot(426); imshow(padarray(best_kernel_byssim,round(0.5*(size(best_kernel_byssim)-size(best_kernel_byssim))),'both'),[]);
        subplot(427); maketitle_d('rec fattal',x,res_fattal{ii}{2},border);
        subplot(428); imshow(padarray(res_fattal{ii}{1}, round(0.5*(size(best_kernel_byssim)-size(res_fattal{ii}{1}))),'both'),[]);
        best_ssim_v(rr) = best_ssim;
        PS_rr{rr} = PS_v;
        best_res_byssim{rr} = { best_kernel_byssim, best_img_byssim };
        best_res_byfractal{rr} = { best_kernel, best_img };
        res_iters_rr{rr} = res_iters;
    end % r2_thres 
    fprintf('done\n');

    res_exp{ii} = { best_res_byfractal, PS_rr };
    res_iters_exp{ii} = res_iters_rr;
    
end % exps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% decide on a best image using the Gaussian and phase criteria

% this requires at least several textures loaded in exps variable to learn properly.
if length(exps)>5
    learning_based_best_ssim_prediction;
else
    % just to allow the algorithm to continue
    best_per_exp = {};
    best_per_exp = { { best_res_byfractal{1}{2},best_res_byfractal{1}{1} } };
end

%% perform wvlt postproc 
imsat = @(x) max(0,min(1,x));
satfunc = imsat;
%satfunc = @(x) x;

wvlt_opts = struct();
wvlt_opts.dt_deblur=0.1;
wvlt_opts.use_dirs = 1:3;
wvlt_opts.use_scales = 2:5;
wvlt_opts.steprange = [-2 0];
wvlt_opts.display_curves=false;
wvlt_opts.disp=false;
wvlt_opts.match_hist=false;
wvlt_opts.desired_scales_minmax = [3 4];
our_wv = cell(1,length(exps_v));

test_wv = cell(1,length(test_exp_idx));
for i=1:length(test_exp_idx), fprintf('.'), end
fprintf('\n\n');
%par
for i=1:length(test_exp_idx)
    fprintf('\b^\n');
    %[x,y,b0,fname] = blur_params_to_data(exps(exps_v(ii)),orig_im,noise_std0);
    %[y,x,b0] = load_exp_fattal_excerpt(src,exps_v(ii));
    ii = test_exp_idx(i);
    x = exps(ii).orig;
    y = exps(ii).deg;
    b0 = exps(ii).kernel;
    our = satfunc(best_per_exp{ii}{1});
    wvlt_ker = fspecial('gaussian',5,0.5); fprintf('using delta as wvlt deb kernel\n');
    [~,test_wv{i}]=selfsim_wavelet_postproc(our,y,x,wvlt_ker,wvlt_opts);
end
for i=1:length(test_exp_idx)
    our_wv{test_exp_idx(i)}=test_wv{i};
end
fprintf('done wvlts\n');

%%
fprintf('\n\nour_wv containts the post-processed images, and\n')
fprintf('best_per_exp contains the results without pre-processing\n');
