function [PS]=maketitle(s,x,y,disp)
if ~exist('disp','var')
    disp=1;
end
d=3;
PSNR1 = @(x,y) PSNR(x(d:end-d+1,d:end-d+1),y(d:end-d+1,d:end-d+1));
ssim1 = @(x,y) ssim(x(d:end-d+1,d:end-d+1),y(d:end-d+1,d:end-d+1));

PS.P=PSNR1(mat2gray(x),mat2gray(y));
PS.S=ssim1(mat2gray(x),mat2gray(y));
if disp
    imshow(y,[]);
    title(sprintf('%s,P%1.2f S%1.3f',...
        s,PS.P,PS.S));
end
end