function [x_res,x_res_sat] = selfsim_wavelet_postproc(use_x,y,x_gt,b,ext_opts)

b_kern1 = b;
wavelet_ratio = 20;

%% params
bluriters=1;
clear opts
opts.grad_thres=0.01;
opts.use_dirs = 1:3;
opts.use_scales = 1:4;
opts.nomeanreduce = true;
opts.wname = 'coif2';
opts.max_prior_iter=100; % after this iteration skip wavelet altogether, just reaction+tv
opts.steprange = [-3 0];
dt_deblur=1; % first iteration
opts.tv_weight = 0;
opts.max_iters = min(10, 1+bluriters*2);
opts.max_iters = min(30, 1+bluriters*6);
%dt_deblur=3; % second iteration, better estimation of the blur filter.
opts.wavelet_ratio = wavelet_ratio;
opts.xray = false; 
opts.dt_deblur=dt_deblur ;%* bluriters * 10;
opts.deblur_in_cost = true;
opts.model_straight_line = false;
%opts.model_straight_line = true; opts.polyord=2;
opts.steerable = false;

opts.match_hist = true;

opts.desired_scales_minmax = [1,5];
opts.min_iters = 60;
opts.decimate = true;
%opts.display_curves = false;
opts.display_curves = true;
opts.curve_thres = 0.00001;

opts.G_external = [];

opts.tv_weight = 0;
opts.grad_thres=0.001;

% apply external struct parameters
opts=merge_struct(opts,ext_opts);

% trials
 %{
opts.max_iters = 100;
opts.dt_deblur = 0;
opts.wavelet_ratio = 1;
opts.steprange = [-3 0];
opts.max_prior_iter=50;
opts.display_curves = true;
opts.desired_scales_minmax = [1 8];
opts.wname = 'coif2';
opts.use_dirs = 1:3;
opts.use_scales = 2:5;
opts.model_straight_line=false;
opts.polyord=1;
opts.nomeanreduce = true;

%Gs.use_dirs = [1:4]; % det det det app
%Gs.use_dirs = [5:7];
%opts.G_external = Gs;
opts.desired_scales_minmax = [1,8];
b_kern1 = fspecial('gaussian',size(b_kern1,2),0.1);fprintf('USING DELTA KERNEL\n');
%}
opts.grad_thres=0.0000001;

x_res = optimize_wavelet_self_similarity(use_x,y,x_gt,b_kern1,opts);
x_res_sat = min(1,max(0,x_res));

end
