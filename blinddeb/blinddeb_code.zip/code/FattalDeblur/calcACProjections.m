function [ acProjections ] = calcACProjections( imgBlur , psSize, myopts )
if ~exist('myopts','var')
    myopts = struct('use',false);
end
% myopts is a struct that selects whether or not to use the custom filter,
% and if so - what's the fractal r2 fit goodness from which to use.
% myopts.use = true|false, myopts.r2thres = 0..1

%calcACProjections Calculate auto-correlation of differentiated projections
%   This function calculates f_theta = R_{d*P_theta(B)} for every theta needed
%   to calculate the power spectrum of the given size. note that for the phase retrieval 
%   to be unique in the 2D case, the power spectrum size should be twice the kernel size.

% ido - a second output term was added - a whitening filter for the
% specific angle via the H estimation of the line
    szK = psSize;
    szK2 = 2*szK;
    szC = szK+1;

    f3 = [3 -32 168 -672 0 672 -168 32 -3]/840; % nine-point 1D differentiation filter
    
    % %{
    fprintf('SETTING CUSTOM d FILTER\n');
    custom = load('custom_d_filt.mat','d');
    f3 = custom.d;
    %}
    
    imgBlurPad = padarray(imgBlur,[4,4],nan);
    imgBlurX = conv2(imgBlurPad,f3,'same');
    imgBlurY = conv2(imgBlurPad,f3','same');
    
    coords = zeros(szK^2,2);
    idxs = zeros(szK^2,2);
    
    % calculate the radius for every x,y coordinate
    j = 1;
    for x=0:szK-1
        for y=0:szK-1
            coords(j,1) = x;
            coords(j,2) = y;
            idxs(j,1) = j;
            idxs(j,2) = sqrt(x^2 + y^2);
            j = j+1;
        end
    end
    
    %
    idxs = sortrows(idxs,2);
    visited = false(szK2+1);
    for j=2:(szK^2)
        idx = idxs(j,1);
        x = coords(idx,1);
        y = coords(idx,2);
        
        if (visited(szC+y,szC+x))
            idxs(j,1) = nan;
            continue;
        end
        
        for i=0:szK
            yOffset = i*y/max(abs(x),abs(y));
            xOffset = i*x/max(abs(x),abs(y));

            if (mod(xOffset,x) ~= 0) || (mod(yOffset,y) ~= 0)
                continue;
            end;

            visited(szC+yOffset,szC+xOffset) = true;
            visited(szC-yOffset,szC-xOffset) = true;
        end
    end
    
    idxs = idxs(~isnan(idxs(:,1)),:);
    numIdxs = size(idxs,1);
    angles = zeros(numIdxs,2);
    xVec = zeros(2*(numIdxs-1),1);
    yVec = zeros(2*(numIdxs-1),1);
    for j=2:numIdxs
        idx = idxs(j,1);
        x = coords(idx,1);
        y = coords(idx,2);

        xVec(2*(j-2)+1) = y;
        yVec(2*(j-2)+1) = x;
        xVec(2*(j-2)+2) = y;
        yVec(2*(j-2)+2) = -x;
    end
    
    % ido - the next function gives a projection of the 'whitened' image
    % in the directions set by the vectors [xVec yVec]
    
    % ido - original Fattal function:
    %[tempSums] = ShearImageC(xVec,yVec,imgBlurX',imgBlurY); 
    % %{
    % ido - my replacement.
    if myopts.use
        fprintf('using MY shearimage, r2 thres: %1.2f\n',myopts.r2_thres);
        [tempSums] = ShearImageMy(imgBlur,[xVec yVec],f3,myopts.r2_thres);
    else
        % if r2 = 1 is the threshold, the default (original) filter will
        % always be used
        [tempSums] = ShearImageMy(imgBlur,[xVec yVec],f3,1);
    end
    %}
    
    % tempSums size is 526 x 562. dim1 is twice the size of imgBlurX or Y,
    % and dim2 is the number of angles. 
    % it is possible that the length is twice since the taken projection
    % can be as long as the diagonal (i.e. length*sqrt2)
    % but, how are the two images imgBlurX and imgBlurY combined?
    
    % interestingly, imgBlurY is changed to the same image but with 1000 on the previously
    % nan'ed borders.
    % Also, the function performs differently when xVec yVec have a single
    % point and if they're vectors.
    % a replicated function, ShearImageMy, was written that does about the
    % same.

    numAngles = size(tempSums,2);
    acProjections2 = zeros(numAngles,2*szK2+1);

    
    parfor j=1:numAngles
        x = xVec(j);
        y = yVec(j);
        angles(j,1) = atan2(x,-y);
        %{
        myproj = radon(imgBlur,180-angles(j,1)*180/pi);
        myproj = myproj(65:300); 
        myproj = myproj-mean(myproj);
        myproj = myproj./norm(myproj);
        %}
        tempSum1 = tempSums(:,j);
        tempSum1 = tempSum1(~isnan(tempSum1));
        tempSum1 = tempSum1 - mean(tempSum1);
        tempSum1 = tempSum1 ./ norm(tempSum1);
        
       
        
        acProjections2(j,:) = acorr(tempSum1,szK2,'space',false);
    end
    [~,sortedIdxs] = sort(angles(:,1),'ascend');
    acProjections = acProjections2([sortedIdxs((end/2) + 1:end);sortedIdxs(1:end/2)],:);
end
