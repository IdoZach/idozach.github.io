function [ deblurredImage ] = runNonBlindDeblurring( img , kernel , numIterations)

    if (nargin < 2)
        error('Usage: [deblurredImage] = runNonBlindDeblurring(image,kernel,<numIterations>)\n')
    end
    if (nargin < 3)
        numIterations = 30;
    end
    if (ischar(img))
        img = im2double(imread(img));
    end
    if (isinteger(img))
        img = im2double(img);
    end
    
    addpath('Utils');
    addpath('NonBlindDeconvolution');
    
    fprintf('Performing non-blind deconvolution: ');
    nonblind = tic;
    deblurredImage = deconvbregman(img,kernel,numIterations);
    toc(nonblind);
    figure; imshow(deblurredImage);

    rmpath('Utils');
    rmpath('NonBlindDeconvolution');
end

