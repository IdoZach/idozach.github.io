function [ deblur1,deblur2 ] = deconvbregman( img , kernel , numIterations)
%DECONVBREGMAN Summary of this function goes here
%   Detailed explanation goes here
    [h w c] = size(img);
    
    opts.kernel_size = size(kernel,1);
    opts.gamma_correct = 1.0;    
    opts.nb_lambda = 3000;
    opts.nb_alpha = 1.0;
    opts.use_ycbcr = 1;
    
    yorig = img;

    b = zeros(opts.kernel_size);
    bhs = floor(size(b, 1)/2);
    
    padsize = bhs;
    dx = [1 -1];
    dy = dx';
  
    if (opts.use_ycbcr)
      if (size(yorig, 3) == 3)
        ycbcr = rgb2ycbcr(yorig);
      else
        ycbcr = yorig;
      end;
      opts.nb_alpha = 1; 
    end;

    if (nargout == 2)
        kernels = [];
        kernels(:,:,1) = kernel;
        kernels(:,:,2) = rot90(kernel,2);
        numKernels = size(kernels,3);
        ppm = ParforProgMon( 'Deconvolution' , numKernels*numIterations);
    else
        kernels = kernel;
        ppm = [];
    end
    numKernels = size(kernels,3);
    
    deblurImages = cell(numKernels,1);
    %parfor
    for q=1:size(kernels,3)
        kernel = kernels(:,:,q);
        deblur = zeros(h,w,c);
        
        if (opts.use_ycbcr == 1)
            ypad = padarray(ycbcr(:,:,1), [padsize padsize], 'replicate', 'both');
            if ~any(kernel(:)) %%% ido addition, otherwise error
                for a = 1:4 
    
                  ypad = edgetaper(ypad, kernel); 
                end;   
            end

            tmp = fast_deconv_bregman(ypad, kernel, opts.nb_lambda, opts.nb_alpha, numIterations, ppm);
            deblur(:, :, 1) = tmp(bhs + 1 : end - bhs, bhs + 1 : end - bhs);
            if (size(ycbcr, 3) == 3)
              deblur(:, :, 2:3) = ycbcr(:, :, 2:3);
              deblur = ycbcr2rgb(deblur);
            end;
        else
          for j = 1:3
            ypad = padarray(yorig(:, :, j), [1 1] * bhs, 'replicate', 'both');
            for a = 1:4 
              ypad = edgetaper(ypad, kernel); 
            end;

            tmp = fast_deconv_bregman(ypad, kernel, opts.nb_lambda, opts.nb_alpha, numIterations, ppm);
            deblur(:, :, j) = tmp(bhs + 1 : end - bhs, bhs + 1 : end - bhs);
          end;
        end;
        deblurImages{q} = deblur;
    end
    
    deblur1 = deblurImages{1};
    if (nargout == 2)
        deblur2 = deblurImages{2};
    end
end

