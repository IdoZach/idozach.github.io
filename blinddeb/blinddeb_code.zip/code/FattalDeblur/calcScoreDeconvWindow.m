function [score, bestWindow] = calcScoreDeconvWindow(kernel, img, use_fractal_score)
% find window, from 'calcKernelFromProjections'
windowSize = 150;
bestWindow = [];
[h,w,~] = size(img);
bestScore = 0;
for i=1:10
    x = randi(w-windowSize);
    y = randi(h-windowSize);
    window = img(y:y+windowSize,x:x+windowSize,:);
    if (size(window,3) == 3)
        window = rgb2gray(window);
    end

    score = var(window(:));
    if (score > bestScore)
        bestWindow = window;
        bestScore = score;
    end;
end

% then, calc score from window
[score] = calcScoreDeconv(kernel,bestWindow, use_fractal_score);
