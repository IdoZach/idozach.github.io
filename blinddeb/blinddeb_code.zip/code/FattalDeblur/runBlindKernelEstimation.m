function [ kernel , acProjections] = runBlindKernelEstimation( img , kernelSize, myopts, undoGammaCorrection, compensation)

    if (nargin < 2)
        error('Usage: [kernel] = runBlindKernelEstimation(image,kernelSize,<compensation>)');
    end
    if nargin<3
        myopts = struct('use',false,'use_fractal_score',false,'use_my_phaseret',false);
    end
    if (nargin < 4)
        undoGammaCorrection = false;
    end
    if (nargin < 5)
       compensation = 2.1; 
    end
    
    if (ischar(img))
        img = im2double(imread(img));
    end
    
    if (isinteger(img))
        img = im2double(img);
    end

    %poolsize = parpool('local',4);
    %if (poolsize == 0)
    %    warning('Better speed can be achieved by using the matlabpool, run: "matlabpool open NUMBER_OF_CORES"');
    %end
    
    addpath('Mex');
    addpath('Utils');
    addpath('NonBlindDeconvolution');
    
    global silentMode;
    silentMode = true;
    
    if (size(img,3) == 3) 
        if (undoGammaCorrection)
           img = img.^(1/2.2);
           img = img / max(img(:));
        end
        img = rgb2gray(img);
    end
    
    [h,w] = size(img);
    sz = min(h,w);
    if (mod(sz,2) == 0)
        sz = sz-1;
    end
    rad = floor(sz/2);
    szC = ceil([h w]/2);
    img = img(szC(1)-rad:szC(1)+rad,szC(2)-rad:szC(2)+rad);

    ticProjections = tic;
    [acProjections] = calcACProjections(img,2*kernelSize,myopts);
    timeProjections = toc(ticProjections);
    fprintf('taking projections took %f seconds\n',timeProjections);
    ticKernel = tic;
    kernel = calcKernelFromProjections('raar',acProjections,kernelSize,compensation,img,...
                                        myopts.use_fractal_score, myopts.use_my_phaseret);
    kernel = kernel(2:end-1,2:end-1);
    kernel = kernel / sum(kernel(:));
    timeKernel = toc(ticKernel);
    fprintf('estimating kernel took %f seconds\n',timeKernel);
    
    clear 'silentMode';
    rmpath('Mex');
    rmpath('Utils');
    rmpath('NonBlindDeconvolution');

end
