function [kernel,res_img]=demo(i, myopts)
    if (nargin < 1)
        i = 1;
    end
    switch i
        case 1
            img = im2double(imread('examples/hollywood.jpg'));
            kernel = runBlindKernelEstimation(img,21);
            runNonBlindDeblurring(img,kernel);
            figure; imshow(img);
        case 2
            img = im2double(imread('examples/lyndsey.png'));
            kernel = runBlindKernelEstimation(img,25);
            runNonBlindDeblurring(img,kernel);
            figure; imshow(img);
        case 3
            img = im2double(imread('examples/venice.png'));
            kernel = runBlindKernelEstimation(img,19);
            runNonBlindDeblurring(img,kernel);
            figure; imshow(img);
        case 4
            img = im2double(imread('examples/I1.png'));
            kernel = runBlindKernelEstimation(img,19);
            runNonBlindDeblurring(img,kernel);
            figure; imshow(img);
        case 5
            img = im2double(imread('examples/I2.png'));
            kernel = runBlindKernelEstimation(img,25);
            runNonBlindDeblurring(img,kernel);
            figure; imshow(img);
        case 6
            img = im2double(imread('examples/I3.png'));
            kernel = runBlindKernelEstimation(img,23);
            runNonBlindDeblurring(img,kernel);
            figure; imshow(img);
        case 7
            img = im2double(imread('examples/I4.png'));
            kernel = runBlindKernelEstimation(img,15);
            runNonBlindDeblurring(img,kernel);
            figure; imshow(img);
        case 8
            img = im2double(imread('examples/texture1.png'));
            kernel = runBlindKernelEstimation(img,11,myopts);
            res_img = runNonBlindDeblurring(img,kernel);
            figure; imshow(img);
        case 9 % for evaluation, here we use EPLL for nonblind deblurring so we don't need to do that here as well
            img = im2double(imread('examples/texture1.png'));
            kernel = runBlindKernelEstimation(img,11);
            res_img = [];
            %figure; imshow(img);
            
    end

end