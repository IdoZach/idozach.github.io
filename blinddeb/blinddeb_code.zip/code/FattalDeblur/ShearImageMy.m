function res_all = ShearImageMy(Z,xy,filt,r2_thres,disp)
if ~exist('disp','var')
    disp = false;
end
if ~exist('r2_thres','var')
    r2_thres = 0.9;
end
f3 = filt; % differentiation filter
N = size(Z,1); % assume square image

res_all = nan(2*N,size(xy,1));

parfor i=1:size(xy,1)
    x = xy(i,1); y=xy(i,2);
    if x<0 && y<abs(x)
        x=-x; y=-y;
        noreverse = false;
    elseif x>0 && x<=abs(y)
        x=-x; y=-y;
        noreverse = true;
    else
        noreverse=false;
    end
    mask = ones(size(Z));

    % decide between vertical or horizontal shear
    cond = x>=abs(y);

    Z1 = Z;
    if cond
        if disp, 'shear x', end
        %Z1 = conv2(Z, f3','same');
        %aa = y/x;
        aa=0;
        bb = y/x;%0;
    else
        if disp, 'shear y', end
        %Z1 = conv2(Z, f3,'same');

        bb = 0;%x/y;
        aa = x/y;
    end
    tform = affine2d([1 bb 0;
                     aa 1 0; 
                      0 0 1]);
    shear0 = imwarp(Z1,tform,'nearest');
    mask = imwarp(mask,tform,'nearest');

    % take only lines with a large number of pixels. It was probably the same
    % in Fattal's ShearImageC implementation.
    thr = N/4;

    % crop boundaries of sheared image
    lf1 = round(length(f3)/2)*0;
    lf2 = round(length(f3)/2)*0+2;
    st1 = 1;
    en1 = 0;


    if cond
        %shear0 =shear0;
        %mask=mask;
        smask = sum(mask,2);
        shear = bsxfun(@(x,y)x./y,shear0 ,smask);
        % this line we can do using MATLAB 2016b but not 2016A...
%        shear = shear0 ./ smask;
        shear = shear(find(smask>=thr,1,'first')+lf1:find(smask>=thr,1,'last')-lf2,st1:end-en1);

        shear = (sum(shear,2));%)./smask;
        if y<0 && noreverse
            shear = shear(end:-1:1);
        end
        if disp
            subplot(222); imagesc(shear0)
            title('sum horiz');
        end
    else
        smask = sum(mask,1);
        shear = bsxfun(@(x,y)x./y,shear0 ,smask);
        % this line we can do using MATLAB 2016b but not 2016A...
        %shear = shear0 ./ smask;

        shear = shear(st1:end-en1,find(smask>=thr,1,'first')+lf1:find(smask>=thr,1,'last')-lf2);
        shear = (sum(shear,1));
        if disp
            subplot(222); imagesc(shear0)
            title('sum vert');
        end
    end
    axis xy
    %dshear = shear; %
    shear = shear(~isnan(shear));

    % original implementation - use a fixed filter
    %shear = conv(shear, f3, 'full');
    % adjustment - custom filter
    %if length(shear)>1
        filt1 = get_adjusted_filter(shear, r2_thres);
    %else
    %    filt1 = f3;
    %end
    shear = conv(shear, filt1, 'full');
    

    % to get rid of edge effects we get by differentiating a vector
    lf1 = round(length(f3)/2)*2;
    lf2 = round(length(f3)/2)*2;
    shear = shear(lf1:end-lf2);

    rad1 = shear;
    origLength = length(rad1); % here for 1:1 comparison we should put the final length of tempSums from Fattal
    rad1 = interp1(1:length(rad1),rad1,linspace(1,length(rad1),origLength));
    rad1 = rad1 - mean(rad1);
    if norm(rad1)>1e-10
        rad1 = rad1 / norm(rad1);
    end
    st = round(N-length(rad1)/2);
    en = round(N+length(rad1)/2)-1;
    rad1 = [ nan(st-1,1); rad1(:); nan(2*N-en,1) ];
    res_all(:,i)=rad1;
    %res_all(st:en,i) = rad1(:);
end

end

function filt = get_adjusted_filter(cur, r2_thres)
    filt_length = 8;
    orig_d = [3 -32 168 -672 0 672 -168 32 -3]/840;
    
    cur = cur(~isnan(cur));
    cur = cur - mean(cur);
    cur = cur ./ norm(cur);

    % ido - save many filters depending on the angle and content
    [b,~,fiterr] = get_hyperbolic_xcorr_exponent(cur);
    %b = b*0.5;
    desired_coef = 2*b-1;
    filt = hp_filter_design(filt_length,256,desired_coef);
    if any(isnan(filt)) || (fiterr.rsquare < r2_thres)
        %filt = orig_d;
        filt = hp_filter_design(filt_length,256,2);
    end
    
end