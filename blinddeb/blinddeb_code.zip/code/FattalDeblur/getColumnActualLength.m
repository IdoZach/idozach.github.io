function [rotX, colsum] = getColumnActualLength(rotX)
vx=zeros(size(rotX,2),2);
for k=1:size(rotX,2)
    vX = [ find(rotX(:,k)~=0,1,'first')+1  find(0~=rotX(:,k),1,'last')-1 ];
    if numel(vX)==0
        vX = [1 size(rotX,1)];
    end
    vx(k,:) = vX;
end
vx = vx(:,2)-vx(:,1);
vx = max(1,vx);
rotX = rotX ./ vx(:)';
colsum = vx(:)';
