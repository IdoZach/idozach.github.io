function [score] = calcScoreDeconv(kernel,img,use_fractal_score)
    if ~exist('use_fractal_score','var')
        use_fractal_score = false;
    end
    try
        img = deconvbregman(img,kernel,10);
    catch me
        score = inf;
        return;
    end
    filter = [-1 1];
    dx = conv2(img,filter,'valid');
    dy = conv2(img,filter','valid');
    dx(size(dy,1)+1:end,:) = 0;
    dy(:,size(dx,2)+1:end) = 0;
    %% L1 / L2 score
    norm1 = sum(abs(dx(:))) + sum(abs(dy(:)));
    norm2 = sqrt(sum(dx(:).^2)) + sqrt(sum(dy(:).^2));
    score = norm1 / norm2;
    if use_fractal_score
    % %{
        fprintf('USING FRACTAL SCORE FOR BEST KERNEL\n');
        d=10;
        [~,~,R2] = estimate_h_2d_inc(img(d:end-d+1,d:end-d+1));
        score = 0.001*score + (1-R2);%*1000;
    %}
    end
end
