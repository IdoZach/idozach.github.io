function [ kernel ] = calcKernelFromProjections(mode, acProjections , kernelSize, compensationFactor, blurredImage, use_fractal_score, use_my_phaseret)
    tic;
    
    % prepare figure
    fig = figure(1);
    drawnow;
    clf;    
    
    global silentMode;
    if (isempty(silentMode)) || (~silentMode)
        plotRows = 5;
        plotCols = 5;
    else
        plotRows = 3;
        plotCols = 1;
        set(fig,'Position',[200,100,200,600]);
    end
    
    if (nargin < 5)
        error('Usage: calcKernelFromProjections(mode, acProjections, kernelSize ,compensationFactor, blurredImage)');
    end
    
    noiseCorrection = false;
    realKernel = [];
    if (nargin < 9)
        guess = [];
        guessMode = [];
    end
    
    % create the deconvolution filter, used to compensate on the fact that the ac after whitening is not a perfect delta
    if (~isempty(compensationFactor)) && (isscalar(compensationFactor)) && (compensationFactor > 1)
        x = (1:201) ;
        d = 1./abs(x).^compensationFactor;
        compensationFilter = zeros(1,401);
        compensationFilter(201:end) = d;
        compensationFilter(1:201) = d(end:-1:1);
    else
        compensationFilter = [];
    end
    
    % the different modes (can be multi / er / hio / raar)
    % ido - modes for phase retrieval
    mode = lower(mode);
    numTries = 30;
    numTries = 3
    switch mode
        case 'hio-er'
            numInnerIterations = 500;
            numOuterIterations = 3;
            prResult = 'median';
        case 'hio'
            numInnerIterations = 500;
            numOuterIterations = 3;
            prResult = 'median';
        case 'er'
            numInnerIterations = 500;
            numOuterIterations = 3;
            prResult = 'median';
        case 'hpr'
            numInnerIterations = 300;
            numOuterIterations = 3;
            prResult = 'last';
        case 'raar'
            numInnerIterations = 300;
            numOuterIterations = 3;
            prResult = 'last';
        otherwise
            error('supported modes: er/hio/hio-er/hpr/raar');
    end
    
    acProjectionsDouble = acProjections;
    [rows,cols] = size(acProjectionsDouble);
    acDoubleRadius =  floor(cols/2);
    acC =       acDoubleRadius+1;
    acRadius =  floor(acDoubleRadius/2);

    % prepare angles and stretch ratios for the different angles
    [sortedAngles,~,sortedRatios] = calcAngles(acRadius);
    sortedAngles = sortedAngles(2:end);
    sortedRatios = sortedRatios(2:end);
    anglesFull = [sortedAngles;-sortedAngles(end:-1:1)];
    ratiosFull = [sortedRatios,sortedRatios(end:-1:1)];

    % if necessary, compensate for the non-perfect delta 
    acProjections = acProjections(:,acC-acRadius:acC+acRadius);
    acProjectionsMins = findLocalMins(acProjections);
    if (~isempty(compensationFilter))
        acCompensatedProjections = deconvACProjections(acProjectionsDouble,compensationFilter,acRadius);
        acCompensatedProjectionsMins = findLocalMins(acCompensatedProjections);
    else
        acCompensatedProjections = acProjections;
        acCompensatedProjectionsMins = acProjectionsMins;
    end
    
    %{
    % ido - see the difference between the compenstaed and original
    subplot(211); hold off; imagesc(acCompensatedProjections)
    subplot(212); hold off; imagesc(acProjectionsDouble)
    input('bla')
    %}
    
    % initial guess of s_thetas (ido - the support)
    if (~isempty(guess))
        acProjectionsK = calcKernelACProjections(imresize(guess,2,'bilinear'),anglesFull,acRadius)';
        acProjectionsK2 = [acProjectionsK , acProjectionsK(:,end-1:-1:1)];
        supportRadon = findCut(acProjectionsK2);
        support = floor(acRadius+1 - (acRadius+1 - supportRadon)./ratiosFull');
    else
        support = findCutGlobalMin(acProjections);
        support = round(findCutLowerBound(support));
    end

    % if the real kernel is provided (for comparison only, calculate the real s_thetas for display purposes
    if (nargin >= 5) && (~isempty(realKernel))
        realKernelBig = realKernel;
        realKernelBig(size(realKernel,1)+4,size(realKernel,1)+4) = 0;
        subplot(5,5,5); imagesc(realKernelBig); title('real kernel');
        realKernelBig(2*acRadius+1,2*acRadius+1) = 0;
        subplot(5,5,4); imagesc(fAbs(realKernelBig)); title('real power spectrum');
        acProjectionsK = calcKernelACProjections(realKernelBig,anglesFull,acRadius)';
        acProjectionsK2 = [acProjectionsK , acProjectionsK(:,end-1:-1:1)];
        realSupportRadon = findCut(acProjectionsK2);
        realSupport = floor(acRadius+1 - (acRadius+1 - realSupportRadon)./ratiosFull');
    else
        realSupport = [];
    end
    
    
    supportPerIteration = [];
    kernels = cell(numOuterIterations,1);
    scores = inf(numOuterIterations,1);
    for i=1:numOuterIterations
        % save and display the support per iteration
        supportPerIteration(end+1,:) = support';
        subplot(plotRows,plotCols,1); plot([realSupport , supportPerIteration']);
        title('support per iteration');
        drawnow;
        
        acProjectionsCorrected = zeros(rows,2*acRadius+1);
        parfor j=1:rows
            % ido - is this the creation of g [ (f+c)/m ] ?
            acProjectionsCorrected(j,:) = cutRow(acCompensatedProjections(j,:),support(j),acProjectionsMins(j,:));
        end
        
        % little median smoothing to reduce noise in the projections
        acProjectionsCorrected = medfilt2cyclic(acProjectionsCorrected,round(2*sqrt(rows)),1);
        powerSpectrum = calcPSfromACProjections(acProjectionsCorrected,acRadius,false,noiseCorrection);

        subplot(plotRows,plotCols,2); imagesc(powerSpectrum); title('target power spectrum');
        
        
        [bestKernel,bestScore,meanKernel] = multiPhaseRetrieval(mode,prResult,numTries,powerSpectrum,kernelSize,numInnerIterations,blurredImage,guessMode,guess,use_fractal_score,use_my_phaseret);
        
        bestKernel(bestKernel < 1e-5) = 0;
        bestKernel = bestKernel / sum(bestKernel(:));
        
        kernels{i} = bestKernel;
        scores(i) = bestScore;
        subplot(plotRows,plotCols,3); imagesc(bestKernel); title('latest kernel'); title(sprintf('latest score: %.8f',bestScore));
        
        % estimate the support given the recovered kernel
        acProjectionsK = calcKernelACProjections(bestKernel,anglesFull,acRadius)';
        acProjectionsK2 = [acProjectionsK , acProjectionsK(:,end-1:-1:1)];
        supportRadon = findCut(acProjectionsK2);
        support = floor(acRadius+1 - (acRadius+1 - supportRadon)./ratiosFull');
        
        drawnow;
    end
    toc;
    
    kernel = bestKernel;
    clear phaseRetrievalC;
end


function [kernels,meanKernels] = multiPhaseRetrievalWithGuess(prMode,numTries,powerSpectrum,kernelSize,numIterations,guessMode,guess,blurredImage,use_my_phaseret)
    NOISE_THRESHOLD = 1e-5;
    if (~isempty(guess))
        guessOrig = guess;
        guessBig = imresize(guess,2,'bilinear');
        szGuess = size(guessBig,1);
        guess = zeros(size(powerSpectrum));
        guess(1:szGuess,1:szGuess) = guessBig;
        guess = wshift('2D',guess,floor([szGuess,szGuess]/2));
        switch lower(guessMode)
            case 'initialguess'
                [kernels,meanKernels] = phaseRetrievalC(powerSpectrum, kernelSize, numTries, numIterations,'mode',prMode,'noiseThreshold',NOISE_THRESHOLD,'initialGuess',guess);
            case 'supportmask'
                [kernels,meanKernels] = phaseRetrievalC(powerSpectrum, kernelSize, numTries, numIterations,'mode',prMode,'noiseThreshold',NOISE_THRESHOLD,'supportMask',guess > 0);
            case 'phases'
                phases = nan(size(powerSpectrum));
                szGuess = size(guessOrig,1);
                phases(1:szGuess,1:szGuess) = angle(fft2(guessOrig));
                phases = wshift('2D',phases,floor([szGuess,szGuess]/2));
                [kernels,meanKernels] = phaseRetrievalC(powerSpectrum, kernelSize, numTries, numIterations,'mode',prMode,'noiseThreshold',NOISE_THRESHOLD,'givenPhases',phases);
            otherwise
                error('unsupported guessMode, should be initialguess/supportmask/phases');
        end
    else
        if ~use_my_phaseret
            [kernels,meanKernels] = phaseRetrievalC(powerSpectrum, ...
                kernelSize, numTries, numIterations,'mode',prMode,...
                'noiseThreshold',NOISE_THRESHOLD);
        else
        %}
        %{
        kernelSize
        numTries
        numIterations
        prMode
        NOISE_THRESHOLD
        %}
        %imagesc(kernels(:,:,1))
        %input('bla')
        %%% %%% ido - original/my phase retrieval:
        
        % %{
          correct_mag = ifftshift(abs(powerSpectrum));
            
          %imagesc(correct_mag), drawnow
          n_out = round(size(powerSpectrum,1) / 2);
          n_out = 19; %round(size(powerSpectrum) / 2);
          disp=false; sparsity_index = 10;
          % get sparsity index using original phase retrieval algorithm.
          %{
          kernels = reshape(kernels,size(kernels,1)*size(kernels,2),size(kernels,3));
          kernels = sum(kernels > 0.01, 1);
          
          sparsity_index = round(mean(kernels))
          %}
          %
          kernels = zeros(n_out,n_out,numTries);
          %sparsity_v = randi([7 40],numTries,1);
          %sparsity_v = randi([6^2 n_out^2],numTries,1);
          %sparsity_v = round([n_out^2/4 n_out^2/8 n_out^2/16]);
          sparsity_v = round([15 20 25]);
          save('correct_mag.mat','correct_mag'); fprintf('saved correct_mag.mat\n');
          for k=1:numTries
              %if k==1
                sparsity_index = sparsity_v(k);
                kernels(:,:,k) = GESPAR_phase_retrieval(correct_mag, sparsity_index, n_out, disp);
                
                %imagesc(kernels(:,:,k)),drawnow
              %else
              %    kernels(:,:,k) = kernels(:,:,1);
              %end
          end
          %maxiter=100;
          %mykernel = phase_retrieval(correct_mag,blurredImage,n_out,maxiter);
          %mykernel(mykernel<0.01)=0;
          %mykernel=mykernel/sum(mykernel(:));
          % ??? 
          %kernels = repmat(mykernel,[1 1 numTries]);
          meanKernels = kernels;
        end
        %}
        %imagesc(kernels(:,:,1))
        %input('bli')
        %%% %%%
    end
end


function [bestKernel,bestScore,medianKernel] = multiPhaseRetrieval(prMode,prResultMode,numTries,powerSpectrum,kernelSize,numIterations,imgBlur,guessMode,guess,use_fractal_score,use_my_phaseret)
    mode = prResultMode;
    
    bestKernels = cell(numTries,1);
    medianKernels = cell(numTries,1);
    bestScores = inf(numTries,1);
    
    [bestKernelsA,medianKernelsA] = multiPhaseRetrievalWithGuess(prMode,numTries,powerSpectrum,kernelSize,numIterations,guessMode,guess,imgBlur,use_my_phaseret);

    % find a good candidate window for score calculation of deconvolution
    % ido - good here means high variance.
    img = imgBlur;
    windowSize = 150;
    bestWindow = [];
    if (~isempty(img))
        [h,w,~] = size(img);

        bestScore = 0;
        for i=1:10
            x = randi(w-windowSize);
            y = randi(h-windowSize);
            window = img(y:y+windowSize,x:x+windowSize,:);
            if (size(window,3) == 3)
                window = rgb2gray(window);
            end

            score = var(window(:));
            if (score > bestScore)
                bestWindow = window;
                bestScore = score;
            end;
        end
    else
        error('invalid: blurry image required');
    end
    
    % calculate the score of each phase retrieval result
    %parfor
    parfor i=1:numTries
        bestKernels{i} = bestKernelsA(:,:,i);
        medianKernels{i} = medianKernelsA(:,:,i);
        kernel = [];

        switch (mode)
            case 'last'
                kernel = bestKernels{i};
            case 'median'
                kernel = medianKernels{i};
            otherwise
                error('invalid mode, should be last/median');
        end
            
        szK = size(kernel,1);
        [xI,yI] = meshgrid(1:szK,1:szK);
        
        kernel = kernel / sum(kernel(:));
        if all(isnan(kernel(:))) %%% ido - solve case of zeros/nans
            kernel = ones(size(kernel));
            kernel = kernel / sum(kernel(:));
        end
        tc = [round(sum(yI(:) .* kernel(:))) , round(sum(xI(:) .* kernel(:)))];
        
        kernel= wshift('2D',kernel, [tc(1)-ceil(szK/2) , tc(2)-ceil(szK/2)]);
        
        
        score1 = calcScoreDeconv(kernel,bestWindow,use_fractal_score);
        score2 = calcScoreDeconv(rot90(kernel,2),bestWindow,use_fractal_score);
        if (score1 < score2)
            bestKernels{i} = kernel;
            bestScores(i) = score1;
        else
            bestScores(i) = score2;
            bestKernels{i} = rot90(kernel,2);
        end
    end
    
    % display top scores
    global silentMode;
    [~,sortedIdxs] = sort(bestScores,'ascend');
    if (isempty(silentMode)) || (~silentMode)
        for i=1:min(5,numTries)
            subplot(5,5,5+i); imagesc(bestKernels{sortedIdxs(i)}); title(sprintf('score: %.8f', bestScores(sortedIdxs(i))));
        end

        % display few other guesses (for comparison)
        if (numTries > 5)
            otherIdxs = sortedIdxs(6:end);
            otherIdxs = otherIdxs(randperm(numel(otherIdxs)));
            for i=1:min(max(5,numTries),15)
                subplot(5,5,10+i); imagesc(bestKernels{otherIdxs(i)}); title(sprintf('score: %.8f', bestScores(otherIdxs(i))));
            end
        end
    end
    
    % return the best one
    [bestScore,minIdx] = min(bestScores);
    bestKernel = bestKernels{minIdx};
    medianKernel = medianKernels{minIdx};
end

%% score calculation mechanisms - in external file


function [cutFunc] = findCut(acProjections, threshold)
    if (nargin < 2)
        threshold = 5e-2;
    end
    
    rows = size(acProjections,1);
    cutFunc = zeros(rows,1);
    for i=1:rows
        rowThreshold = threshold * max(acProjections(i,:));
        cutFunc(i) = max(1,find(acProjections(i,:) > rowThreshold,1,'first')-1);
    end
end

function [cutFunc] = findCutGlobalMin(acProjections)
    rows = size(acProjections,1);
    cols = size(acProjections,2);
    cutFunc = zeros(rows,1);
    for i=1:rows
        [~,minIdx] = min(acProjections(i,1:floor(cols/2)));
        cutFunc(i) = minIdx;
    end
end

function [boundFunc] = findCutLowerBound(cutFunc)
    maxSlope = 20/700;
    rows = size(cutFunc,1);
    boundFunc = zeros(rows,1);
    [~,sortedIdxs] = sort(cutFunc,'descend');
    for i=1:rows
        peakIdx = sortedIdxs(i);
        peakVal = cutFunc(peakIdx);
        if (peakVal > boundFunc(peakIdx))
            boundFunc(peakIdx) = peakVal;
            for j=1:floor(rows/2);
                prevRow = mod(peakIdx-j-1,rows)+1;
                nextRow = mod(peakIdx+j-1,rows)+1;
                boundFunc(prevRow) = max(boundFunc(prevRow),peakVal - j*maxSlope);
                boundFunc(nextRow) = max(boundFunc(nextRow),peakVal - j*maxSlope);
            end
        end
    end
end

function [localMins] = findLocalMins(acProjections)
    rows = size(acProjections,1);
    cols = size(acProjections,2);
    localMins = false(rows,cols);
    for i=1:rows
        row = acProjections(i,:);
        for j=2:cols-2
            if (row(j-1) > row(j)) && (row(j+1) > row(j))
                localMins(i,j) = true;
            end
        end
    end
end

function [acRow] = cutRow(acRow,cut,acProjectionsLocalMins)
    cut = max(cut,1);
    
    for i=0:1
        if (cut + i < size(acRow,2)) && (acProjectionsLocalMins(cut+i))
            cut = cut+i;
            break;
        end
        if (cut-i > 1) && (acProjectionsLocalMins(cut-i))
            cut = cut-i;
            break;
        end
    end
    
    cutVal = acRow(cut);
    acRow(1:cut) = cutVal;
    acRow(end-cut+1:end) = cutVal;
    acRow(acRow < cutVal) = cutVal;
    acRow = acRow - cutVal;
    acRow = acRow ./ sum(acRow);
end


function [acProjections] = calcKernelACProjections(kernel,angles,acRadius)
    kradons = radon(kernel,angles*180/pi);
    acProjections = acorrFast(kradons,acRadius);
end


function [out] = acorrFast(data,windowRadius)
    data = padarray(data,[windowRadius,0],0);
    f = fft(data);
    f = abs(f).^2;
    out = ifft(f);
    out = out(windowRadius+1:-1:1,:);
end

function [B] = medfilt2cyclic(A,M,N)
    if (M > 1)
        A = [A(end-M+2:end,:);A;A(end:-1:end-M+2,:)];
    end
    if (N > 1)
        A = [A(:,end-N+2:end),A,A(:,end:-1:end-N+2)];
    end
    B = medfilt2(A,[M N]);
    B = B(M:end-M+1,N:end-N+1);
end

function [acProjectionsOut] = deconvACProjections(acProjections,deconvFilter,acRadius)
    [rows,~] = size(acProjections);
    acProjectionsOut = zeros(rows,2*acRadius+1);
    szC = acRadius+1;
    szC2 = floor(size(acProjections,2)/2)+1;
    parfor i=1:rows
        rowFilter = deconvFilter;
        newRow = deconvAC(acProjections(i,:),rowFilter,acRadius);
        if (any(newRow(szC-2:szC+2) < 0))
            acProjectionsOut(i,:) = acProjections(i,szC2-acRadius:szC2+acRadius);
        else
            acProjectionsOut(i,:) = newRow;
        end
    end
end

function [ac] = deconvAC(acBlur,deconvFilter,szK)
    szK2 = 2*szK;
    szK4 = 4*szK;

    acM = deconvFilter;
    meanC = floor(max(size(acM))/2)+1;
    acM = acM(meanC - szK2 : meanC + szK2);

    acM = acM / max(acM);

    sz = szK4+1;

    A = nan(sz,szK+1);
    b = nan(sz,1);
    for m=szK+1:sz-szK
        A(m,1:szK) = acM(m-szK:m-1) + acM(m+szK:-1:m+1);
        A(m,szK+1) = acM(m);
        b(m) = acBlur(m);
    end

    A = A(szK+1:sz-szK,:);
    b = b(szK+1:sz-szK);
    res = (A'*A) \ (A'*b);
    ac = zeros(1,szK2+1);
    ac(1:szK) = res(1:end-1)';
    ac(szK+1) = res(end)';
    ac(szK+2:2*szK+1) = res(end-1:-1:1)';
end
