function [ out ] = fAbs( data , windowRadius )
    if (min(size(data)) > 1)
        F = fft2(data);
        F = abs(F).^2;
        out = F;
        out = fftshift(out);
    else
        F = fft(data);
        F = abs(F).^2;
        out = F;
        out = fftshift(out);
    end

    if (nargin > 1)
        [h w] = size(out);
        h = floor(h / 2)+1;
        w = floor(w / 2)+1;
        
        if (h > 1)
            out = out(h-windowRadius:h+windowRadius,:);
        end
        if (w > 1)
            out = out(:,w-windowRadius:w+windowRadius);
        end
    end
end

