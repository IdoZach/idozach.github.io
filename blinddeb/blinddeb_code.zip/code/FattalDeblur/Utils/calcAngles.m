function [sortedAngles,sortedIdxs,sortedRatios] = calcAngles(kernelSize)
    szK = kernelSize;
    szK2 = 2*szK;
    szC = szK+1;

    idxs = zeros(szK.^2,2);
    angles = zeros(szK.^2,1);
    for j=1:szK^2
        [y,x] = ind2sub([szK,szK],j);
        y = y - 1;
        x = x - 1;        
        idxs(j,1) = j;
        idxs(j,2) = sqrt(x^2 + y^2);
    end
    idxs = sortrows(idxs,2);
    
    visited = false(szK2+1);
    for j=2:(szK^2)
        idx = idxs(j,1);
        [y,x] = ind2sub([szK,szK],idx);
        y = y - 1;
        x = x - 1;
        
        angles(j) = [atan2(y,-x)];
        ratios(j) = cos(atan2(min(abs(x),abs(y)),max(abs(x),abs(y))));
    
        if (visited(szC+y,szC+x))
            idxs(j,1) = nan;
            angles(j) = nan;
            continue;
        end
        
        for i=0:szK
            yOffset = i*y/max(abs(x),abs(y));
            xOffset = i*x/max(abs(x),abs(y));

            if (mod(xOffset,x) ~= 0) || (mod(yOffset,y) ~= 0)
                continue;
            end;

            visited(szC+yOffset,szC+xOffset) = true;
            visited(szC-yOffset,szC-xOffset) = true;
        end
    end
    
    angles = angles(~isnan(idxs(:,1)));
    ratios = ratios(~isnan(idxs(:,1)));
    [sortedAngles,sortedIdxs] = sort(angles,'ascend');
    sortedRatios = ratios(sortedIdxs);
end