function [ warped ] = warpFast( img, motion )
%WARPFAST Warp the given image by the given motion
%   This method uses backward-warping to warp the image by the given
%   motion. It is done fast using convolutions, and without using interp2.
%   It only supports translation in x,y axis
%
%   img     : input image to warp
%   motion  : warping vector [x y] , the x,y translation
%
%   warped  : image after warping. the size of the image is exactly the
%   same as the original. 
%

    u = motion(1);
    v = motion(2);
    cv = ceil(abs(v))+1;
    cu = ceil(abs(u))+1;

    filter1 = zeros(2*cv+1,1);
    filter2 = zeros(2*cu+1,1);

    % split to whole part and reminder
    u_int = fix(u);
    v_int = fix(v);
    u_rem = abs(u-u_int);
    v_rem = abs(v-v_int);

    % Sign = 1/-1
    sign_u = sign(u);
    sign_v = sign(v);

    % set the actual filters values
    filter2(cu+1+u_int+sign_u) = u_rem;
    filter1(cv+1+v_int+sign_v) = v_rem;
    filter2(cu+u_int+1) = 1-u_rem;
    filter1(cv+v_int+1) = 1-v_rem;

    % do the actual warping
    filter2 = filter2';
    warped = img;
    for i=1:size(warped,3)
       warped(:,:,i) = conv2(filter1,filter2,warped(:,:,i),'same');
    end
end
