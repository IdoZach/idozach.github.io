function [ssde,tI1]=comp_upto_shift(I1,I2,limitedShift,maxshift)
%function [ssde,tI1]=comp_upto_shift(I1,I2)
%  compute sum of square differences between two images, after
%  finding the best shift between them. need to account for shift
%  because the kernel reconstruction is shift invariant- a small 
%  shift of the image and kernel will not effect the likelihood score.
%Input:
%I1,I2-images to compare
%Output:
%ssde-sum of square differences
%tI1-image I1 at best shift toward I2
%
%Writen by: Anat Levin, anat.levin@weizmann.ac.il (c)

[N1,N2]=size(I1);

if (nargin < 3)
    limitedShift = false;
end

if (nargin < 4)
    maxshift=5;
end

if (limitedShift)
    shifts=(-maxshift:1:maxshift);
else
    shifts=(-maxshift:0.25:maxshift);
end


if (size(I1,3) == 3)
    I1 = rgb2gray(I1);
    I2 = rgb2gray(I2);
end

sz = 500;
[h,w] = size(I1);
xOffset = floor((w-sz)/2);
yOffset = floor((h-sz)/2);
I1 = I1(yOffset:yOffset+sz-1,xOffset:xOffset+sz-1);
I2 = I2(yOffset:yOffset+sz-1,xOffset:xOffset+sz-1);

I2=I2(16:end-15,16:end-15);
I1=I1(16-maxshift:end-15+maxshift,16-maxshift:end-15+maxshift);
[N1,N2]=size(I2);
[gx,gy]=meshgrid([1-maxshift:N2+maxshift],[1-maxshift:N1+maxshift]);

[gx0,gy0]=meshgrid([1:N2],[1:N1]);
 


for i=1:length(shifts)
   for j=1:length(shifts)

     gxn=gx0+shifts(i);
     gyn=gy0+shifts(j);
     tI1 = warpFast(I1,[-shifts(i),-shifts(j)]);
     tI1 = tI1(maxshift+1:end-maxshift,maxshift+1:end-maxshift);
     ssdem(i,j)=sum((tI1(:)-I2(:)).^2);
    
   end
end

ssde=min(ssdem(:));

if (nargout == 2)
    [i,j]=find(ssdem==ssde);

    gxn=gx0+shifts(i);
    gyn=gy0+shifts(j);
    tI1=interp2(gx,gy,I1,gxn,gyn);
end