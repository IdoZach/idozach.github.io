function [ out ] = acorr( data , windowRadius , mode , normalized)

    if (nargin < 3)
        mode = 'fourier';
    end
    
    if (nargin < 4)
        normalized = false;
    end
    
    if (min(size(data)) > 1)
        dim = 2;
    else
        dim = 1;
    end

    switch mode
        case 'space'
            if (nargin < 2)
                error ('required: window radius');
            end
            
            if (dim == 2)
                error('2D not yet supported');
            else
                out = zeros(1,2*windowRadius+1);
                data1 = data(windowRadius+1:end-windowRadius);
                if (normalized)
                    m = mean(data1);
                    data1 = data1 - m;
                    n = norm(data1);
                    data1 = data1 / n;
                    data = data - m;
                    data = data / n;
                end

                for i=0:windowRadius
                    data2a = data(windowRadius+1-i : end-windowRadius-i);
                    data2b = data(windowRadius+1+i : end-windowRadius+i);
                    res = (sum(data1 .* data2a) + sum(data1 .* data2b)) / 2;
                    out(windowRadius+1-i) = res;
                    out(windowRadius+1+i) = res;
                end
                out = out / max(size(data1));
            end
        case 'fourier'
            if (normalized)
                data = data - mean(data);
                data = data / norm(data);
            end
            if (dim == 2)
                F = fft2(data);
                F = abs(F).^2;
                out = ifft2(F);
                out = fftshift(out);
            else
                F = fft(data);
                F = abs(F).^2;
                out = ifft(F);
                out = fftshift(out);
            end

            if (nargin > 1)
                [h w] = size(out);
                h = floor(h / 2)+1;
                w = floor(w / 2)+1;

                if (h > 1)
                    out = out(h-windowRadius:h+windowRadius,:);
                end
                if (w > 1)
                    out = out(:,w-windowRadius:w+windowRadius);
                end
            end
    end
end

