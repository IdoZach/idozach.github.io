function [ img,imgC ] = loadImage( filename )
    imgC = im2double(imread(filename));
    img = rgb2gray(imgC);
    [h,w] = size(img);
    sz = min(h,w);
    if (mod(sz,2) == 0)
        sz = sz-1;
    end
    rad = floor(sz/2);
    szC = ceil([h w]/2);
    img = img(szC(1)-rad:szC(1)+rad,szC(2)-rad:szC(2)+rad);
end

