Blur Kernel Estimation from Spectral Irregularities
Amit Goldstein & Raanan Fattal , August 2012
http://www.cs.huji.ac.il/~raananf/projects/deblur
---------------------------------------------------------------
Usage of this code is free for research purposes only.
(c) Amit Goldstein, amit.goldstein@mail.huji.ac.il August 2012.
---------------------------------------------------------------

This file contains the code for the algorithm presented in our paper from ECCV 2012.
This is the cpu-optimized version with the same parameters used to achieve all the results presented in our paper. It's currently built for win64.
When running on multi-core machines, using the matlabpool will improve running times: run "matlabpool open NUMBER_OF_CORES" to activate the pool for the current matlab session.

demo.m contains a script for running the demo code.

Please send bug reports to <amit.goldstein@mail.huji.ac.il>


Acknowledgments:
For the non-blind deconvolution, we used an implementation based on the NIPS 2009 paper of Krishnan and Fergus "Fast Image Deconvolution using Hyper-Laplacian Priors"
And would like to thank the authors for making the code available.

