function [ powerSpectrum , acProj ] = calcPSfromACProjections( acProjections , psSize , interpolate , noiseCorrection)
% calcPSfromACProjections Calcaulte the power spectrum from the projections f_theta

    if (nargin < 3) 
        interpolate = false;
    end
    
    if (nargin < 4)
        noiseCorrection = false;
    end

    szK = psSize;
    szK2 = 2*szK;
    szC = szK+1;

    coords = zeros(szK^2,2);
    idxs = zeros(szK^2,2);
    angles = zeros(szK^2,2);
    
    j = 1;
    for x=0:szK-1
        for y=0:szK-1
            coords(j,1) = x;
            coords(j,2) = y;
            idxs(j,1) = j;
            idxs(j,2) = sqrt(x^2 + y^2);
            j = j+1;
        end
    end
    idxs = sortrows(idxs,2);
    
    visited = false(szK2+1);
    for j=2:(szK^2)
        idx = idxs(j,1);
        x = coords(idx,1);
        y = coords(idx,2);
        
        angles(j,:) = [atan2(x,y),atan2(-x,y)];
        if (visited(szC+y,szC+x))
            idxs(j,1) = nan;
            angles(j,:) = nan;
            continue;
        end
        
        for i=0:szK
            yOffset = i*y/max(abs(x),abs(y));
            xOffset = i*x/max(abs(x),abs(y));

            if (mod(xOffset,x) ~= 0) || (mod(yOffset,y) ~= 0)
                continue;
            end;

            visited(szC+yOffset,szC+xOffset) = true;
            visited(szC-yOffset,szC-xOffset) = true;
        end
    end
    
    
    angles = angles(~isnan(idxs(:,1)),:);
    idxs = idxs(~isnan(idxs(:,1)),:);
    numIdxs = size(idxs,1);
    [~,sortedIdxs] = sort(angles,'ascend');
    
    acKs = cell(numIdxs,2);
    acKs(sortedIdxs(2:end,1),1) = mat2cell(acProjections(1:numIdxs-1,:),ones(numIdxs-1,1),size(acProjections,2));
    acKs(sortedIdxs(end:-1:2,1),2) = mat2cell(acProjections(numIdxs:end,:),ones(numIdxs-1,1),size(acProjections,2));

    powerSpectrum = zeros(szK2+1);
    acProj = zeros(szK2+1,szK2+1,numIdxs*2);
    
    visited = false(szK2+1);
    for j=2:numIdxs
        idx = idxs(j,1);
        x = coords(idx,1);
        y = coords(idx,2);
        
        angle = atan2(min(abs(x),abs(y)),max(abs(x),abs(y)));
        ratio = cos(angle);

        if (visited(szC+y,szC+x))
            continue;
        end

        acKm = acKs{j,1};
        if (interpolate)
            acKm = interp1(-szK:szK,acKm,-szK*ratio:ratio:szK*ratio);
        end
        psKm = abs(fft(acKm));
        psKm = psKm / psKm(1) * size(psKm,1);
        
        if (noiseCorrection)
            psKm = psKm - (mean(psKm(szC-10:szC)))/2;
            psKm(psKm < 0) = 0;
        end
        
        psKm = psKm / psKm(1);
        psKm = (fftshift(psKm));
        
        for i=0:szK
            yOffset = i*y/max(abs(x),abs(y));
            xOffset = i*x/max(abs(x),abs(y));

            if (mod(xOffset,x) ~= 0) || (mod(yOffset,y) ~= 0) || (visited(szC+yOffset,szC+xOffset))
                continue;
            end;

            powerSpectrum(szC+yOffset,szC+xOffset) = psKm(szC+max(abs(yOffset),abs(xOffset)));
            powerSpectrum(szC-yOffset,szC-xOffset) = psKm(szC+max(abs(yOffset),abs(xOffset)));
            acProj(szC+yOffset,szC+xOffset,2*(j-1)+1) = acKm(szC+max(abs(yOffset),abs(xOffset)));
            acProj(szC-yOffset,szC-xOffset,2*(j-1)+1) = acKm(szC+max(abs(yOffset),abs(xOffset)));
            visited(szC+yOffset,szC+xOffset) = true;
            visited(szC-yOffset,szC-xOffset) = true;
        end

        acKm = acKs{j,2};
        if (interpolate)
            acKm = interp1(-szK:szK,acKm,-szK*ratio:ratio:szK*ratio);
        end
        psKm = abs(fft(acKm));
        psKm = psKm / psKm(1) * size(psKm,1);
        
        if (noiseCorrection)
            psKm = psKm - (mean(psKm(szC-10:szC)))/2;
            psKm(psKm < 0) = 0;
        end
        
        psKm = psKm / psKm(1);
        psKm = (fftshift(psKm));

        for i=0:szK
            yOffset = -i*y/max(abs(x),abs(y));
            xOffset = i*x/max(abs(x),abs(y));

            if (mod(xOffset,x) ~= 0) || (mod(yOffset,y) ~= 0) || (visited(szC+yOffset,szC+xOffset))
                continue;
            end;

            powerSpectrum(szC+yOffset,szC+xOffset) = psKm(szC+max(abs(yOffset),abs(xOffset)));
            powerSpectrum(szC-yOffset,szC-xOffset) = psKm(szC+max(abs(yOffset),abs(xOffset)));
            acProj(szC+yOffset,szC+xOffset,2*(j-1)+2) = acKm(szC+max(abs(yOffset),abs(xOffset)));
            acProj(szC-yOffset,szC-xOffset,2*(j-1)+2) = acKm(szC+max(abs(yOffset),abs(xOffset)));
            visited(szC+yOffset,szC+xOffset) = true;
            visited(szC-yOffset,szC-xOffset) = true;
        end
    end
    
    powerSpectrum(szC,szC) = 1;
    acProj(:,:,4) = 0;
    acProj(:,:,6) = 0;
    acProj(szC,szC,:) = 0;

    acKm = acKs{2,1};
    acProj(szC,szC,1) = acKm(szC);
    acProj = sum(acProj,3);
end

