function [d, h] = hp_filter_design(filt_sz, N, coef, disp)
%%
if ~exist('filt_sz','var')
    filt_sz = 8; % should be even
end
if ~exist('N','var')
    N=128;
end
if ~exist('coef','var')
    coef = 2;
end
if ~exist('disp','var')
    disp = false;
end
% design a specific filter
%coef=7;
v = linspace(0,1,N);
D = v.^(coef/2) ;
px = round(3*N/4);
Dp = D(px);
pcoor = v(px);
rest = -Dp/(1-pcoor) * (v-1);
D = [D(1:px) rest(px+1:end)];
%hold off; plot(D); input('')
%logist = (1-1./(1+exp(-10*(v-v(end/2)))));
%D = D .* logist + D(end:-1:1) .* (1-logist);
v = linspace(0,1,N);
%D = D.* D(end:-1:1);
H_desired = D.*conj(D);
H_desired = H_desired / max(H_desired);
%H = [H(end:-1:1) H(2:end)];

d = firls(filt_sz,v,D,'hilbert');
d = d / sum(d(d>0));

h = conv(d,d(end:-1:1));

if disp
    fpath='c:\users\ido\dropbox\grad\papers\paper11phase\filter_';
    d_orig=[3,-32, 168,-672, 0, 672,-168, 32,-3]/840;
    H1 = abs(fft(h,length(v)*2));
    H1 = H1(1:end/2);
    H1=H1/max(H1);
    h_freqres = subplot(221); 
    
    figure(1); clf;
    lw=3; ts=18;
    hold off;   plot(v,H_desired,'linewidth',lw)
    hold on;    plot(v,H1,'r--','linewidth',lw)
    set(gca,'fontsize',ts), xlabel('\theta [\pi Rad]'), ylabel('H(\theta)')
    legend('desired','designed','location','best');
    save2pdf([fpath 'freq.pdf'],gcf);

    clf
    %h_taps = subplot(222); hold off; 
    plot(d,'linewidth',lw), title('Whitening filters');
    hold on;
    plot(d_orig,'r--','linewidth',lw)
    set(gca,'fontsize',ts), xlabel('n'), ylabel('d[n]')
    legend('Designed','Laplacian','location','best');
    save2pdf([fpath 'taps.pdf'],gcf)

    subplot(224); hold off;
    plot(h,'linewidth',lw), title('d*d''');
    hold on;
    plot(conv(d_orig,d_orig(end:-1:1)),'r--','linewidth',lw);
    set(gca,'fontsize',ts), xlabel('n'), ylabel('h[n]')

    subplot(223); hold off;
    plot(abs(fft(conv(d,fliplr(d)),128)));
    hold on;
    plot(abs(fft(conv(d_orig,fliplr(d_orig)),128)));
    axis tight; 
    
    %save_subplot(h_freqres,[fpath 'taps.pdf'])    
    %save_subplot(h_taps,[fpath 'freq.pdf'])
    save_infofile([fpath 'info.txt'], sprintf('coef: %1.2f',coef));
    % d
    %{
    hold off;
    plot(abs(fft(d,128)));
    hold on;
    plot(abs(fft(d_orig,128)));
    axis tight;
    %}
    %subplot(223); hold off; stem(d); hold on; stem(([3,-32, 168,-672, 0, 672,-168, 32,-3]/840))
    %title('estimated d vs. fattal''s d');
end
%%

end