function [congrus, Phi, M, m] = gabor_phases(im, wavelengths, orientations)
congrus = zeros(size(im,1),size(im,2),length(orientations));
% for isotropic congruency
a = im*0;
b = im*0;
c = im*0; 
im = im - mean(im(:));
im = im ./ std(im(:));

T = 2;

for o = 1:length(orientations)
    gmags = zeros(size(im,1),size(im,2),length(wavelengths));
    gphases = gmags;
    
    orientation = orientations(o);
    for i = 1:length(wavelengths)
        w = wavelengths(i);
        [mag,phase] = imgaborfilt(im,w,orientation);
        gphases(:,:,i) = phase;
        gmags(:,:,i) = mag;
    end
    
    % convert to mag/phase across frequencies
    gmagv = reshape(gmags,size(gmags,1)*size(gmags,2),[]);
    gphasev = reshape(gphases,size(gmags,1)*size(gmags,2),[]);

    meanphase = mean(gphasev,2);
    deltaphi = cos(gphasev-meanphase) - abs(sin(gphasev-meanphase)) ;
    numer = max(0, gmagv.*deltaphi - T);
    eps = 0.001 / size(gmagv,2);
    
    % per orientation phase congruency
    congru = sum(numer,2) ./ sum(gmagv+eps,2) ;
    congru = reshape(congru, size(im,1), []);
    congru = max(congru,0); %%% why???
    congrus(:,:,o) = congru;

    a(:,:) = a(:,:) + (congru*cos(orientation*pi/180)).^2 ;
    b(:,:) = b(:,:) + 2*congru*cos(orientation*pi/180).*congru*sin(orientation*pi/180) ;
    c(:,:) = c(:,:) + (congru*sin(orientation*pi/180)).^2 ;
    
end

denom = sqrt(b.^2 + (a-c).^2 );
Phi = 0.5 * atan2( b ./ denom , (a-c) ./ denom );
M = 0.5 * (a+c+denom);
m = 0.5 * (a+c-denom);

% obtain isotropic congruency (P. Kovesi, 1999)






end