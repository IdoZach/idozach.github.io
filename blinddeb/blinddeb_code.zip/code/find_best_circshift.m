% cirshifts y around [0,0] and finds the one with the best PSNR w.r.t x
function shifted=find_best_circshift(x,y)
v=[-6:6];
v = [-12:12]; 
fprintf('using larger neighborhood to find best circshift... (onlyfattal)\n');
resv = zeros(length(v));
for i=1:length(v)
    for j=1:length(v)
        res = maketitle('',x,circshift(y,[v(i) v(j)]),0);
        resv(i,j)=res.S;
    end
end
[maxx,maxy]=find(resv==max(resv(:)));
shifted = circshift(y,[v(maxx) v(maxy)]);
%maketitle('',x,shifted);