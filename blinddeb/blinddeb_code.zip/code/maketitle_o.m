% same as maketitle_d but overlays ('o') the psnr and ssim
% on the image itself
function [PS]=maketitle_o(s,x,y,d,overlay,smallimg)
if ~exist('overlay','var')
    overlay=1;
end
if ~exist('smallimg','var')
    smallimg=true;
end
if ~exist('d','var')
    d=3;
end
x = x(d:end-d+1,d:end-d+1);
y = y(d:end-d+1,d:end-d+1);
PSNR1 = @(x,y) PSNR(x,y);
ssim1 = @(x,y) ssim(x,y);

PS.P=PSNR1(mat2gray(x),mat2gray(y));
PS.S=ssim1(mat2gray(x),mat2gray(y));
N=size(y,1);N2=round(N/2);N4=round(N/8);
N3=round(N/3);
fsize=18;
if smallimg
    y(1:N3,N-N3+1:N)=addborder(imresize(y(N2-N4:N2+N4,N2-N4:N2+N4),[N3 N3]));
end
if overlay
    y=insertText(y,[1 size(y,1)],... 
        sprintf('P%1.2f,S%1.3f',PS.P,PS.S),...
        'AnchorPoint','LeftBottom','BoxOpacity',0.8,'fontsize',fsize,'font','Arial Bold');
end
    imshow(y,[]);
    title(sprintf('%s',s),'fontsize',10);
end
function x=addborder(x)
d=3;
val = min(x(:));
x(1:d,:)=val;
x(:,1:d)=val;
x(end-d+1:end,:)=val;
x(:,end-d+1:end)=val;
end