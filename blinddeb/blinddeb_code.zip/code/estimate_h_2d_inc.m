function [h,allVar,R2] = estimate_h_2d_inc(x,max_tau)
if nargin==1
    max_tau=10;
end
if length(max_tau)==2 % vector
    min_tau = max_tau(1);
    max_tau = max_tau(2);
else
    min_tau = 2;
end
N=length(x);
tau_vect = min_tau:max_tau;
reg.X = [log(tau_vect(:)) ones(numel(tau_vect),1)];
W=diag((N-tau_vect));
varX2 = tau_vect*0;
allVar = [];
for i=1:length(tau_vect)
    cura = x;
    t = tau_vect(i);
    X = cura(1:end-t,:) - cura(t+1:end,:);
    X = X(:,1:end-t) - X(:,t+1:end);
    %imshow(X,[]); pause(1),drawnow;
    varX2(i) = sum(X(:).^2)/(length(X(:)));
    allVar = [allVar varX2(i)];
end
reg.Y = log(varX2(:));
SStot = sum( (reg.Y-mean(reg.Y)).^2 );
%ltauvect = log(tau_vect);
A = (reg.X'*W*reg.X)^-1*reg.X'*W*reg.Y;
%size((reg.X'*W*reg.X)^-1*reg.X'*W)
AA = (eye(length(tau_vect))-reg.X*(reg.X'*reg.X)^-1*reg.X');
AAA = AA'*AA;
SSres = reg.Y'*AAA*reg.Y;
R2 = 1-SSres/SStot;
%[~,gof]=fit(log(tau_vect(:)),reg.Y,'poly1'); gof.rsquare

p = A(:)';
h = p(1)/2;
end