function xv_im = optimize_wavelet_self_similarity(x_initial,y,x_orig,b_kern,opts)

%deblur_in_cost = false; fprintf('DEBLUR TERM OUTSIDE COST\n');
deblur_in_cost = opts.deblur_in_cost;
steprange = opts.steprange;
model_straight_line = opts.model_straight_line;
steerable = opts.steerable;
xray = opts.xray;
dt = opts.dt_deblur;
tv_weight = opts.tv_weight;
max_iters = opts.max_iters;
min_iters = opts.min_iters;
decimate = opts.decimate;
max_prior_iter = opts.max_prior_iter;
display_curves = opts.display_curves;
curve_thres = opts.curve_thres; % threshold for norm of selfsim curve difference
grad_thres = opts.grad_thres;
wavelet_ratio = opts.wavelet_ratio;
if isfield(opts,'G_external')
    use_external_GG = true;
    Gs = opts.G_external;
else
    use_external_GG = false;
end
if isfield(opts,'polyord')
    polyord = opts.polyord; % 1 or 2 
else
    polyord = 1;
end
if isfield(opts,'disp')
    disp = opts.disp;
else
    disp = true;
end
desired_scales = opts.desired_scales_minmax;
%deblur_in_cost = true;
%model_straight_line = true; fprintf('using straight line as model\n')
%model_straight_line = false; 
%steerable=false;
%steerable=true; fprintf('USING STEERABLE\n');
% prepare matrices
sz = size(x_initial,1);
sz2 = sz/2;
if isfield(opts,'wname')
    wname = opts.wname;
else
    wname = 'coif2';
end

if steerable
    n=min(log2(sz2)-2,3);
    steerable_name = 'sp3Filters';
    [GG,GG2,use_scales,use_dirs,tot_dirs]=get_G_matrices_steerable(sz,sz2,n,steerable_name);
else
    n=min(log2(sz2)-2,4);
    if use_external_GG
        %fprintf('using external GGs\n');
        %GG=Gs.GG;
        %GG2=Gs.GG2;
        %use_scales=Gs.use_scales;
        %use_dirs=Gs.use_dirs;
        %tot_dirs=Gs.tot_dirs;
    else
        [GG,GG2,use_scales,use_dirs,tot_dirs]=get_G_matrices(sz,sz2,n,wname,decimate);
    end
    %use_scales = max(desired_scales(1),use_scales(1)): ...
%        min(desired_scales(2),use_scales(end));
                
end
use_dirs = opts.use_dirs;
tot_dirs = length(use_dirs);
use_scales = opts.use_scales;


fprintf('using scales %d:%d\n',use_scales(1),use_scales(end));
y2 = imresize(y,0.5);
y2 = imresize(x_initial,0.5); fprintf('using cur x for y2 calculation\n')
y2 = min(1,max(0,y2));

fprintf('calculating desired variances... ')
params=struct('n',n,'use_dirs',use_dirs,'tot_dirs',tot_dirs,'use_scales',use_scales,...
    'model_straight_line',model_straight_line,'polyord',polyord,'wname',wname,...
    'nomeanreduce',opts.nomeanreduce);
V = calculate_desired_variance_model([],[],y,y2,params);
fprintf('done\n');

%%
xv = x_initial(:);
if steerable
    plot_steerable_wavelet_decays_x_y_y2(x_orig,x_initial,338,'v');
    subplot(338); title('orig status v');
    plot_steerable_wavelet_decays_x_y_y2(x_orig,x_initial,339,'a');
else
    %{
    params=struct('n',n,'tot_dirs',tot_dirs,'use_dirs',use_dirs,...
            'use_scales',use_scales,'do_y2',~model_straight_line,'ylim',[-4 4],...
            'polyord',polyord);
    plot_wavelet_decays_x_GG(x_orig,x_initial,params,GG,8,1,GG2);
    subplot(338); title('orig status v');
    plot_wavelet_decays_x_GG(x_orig,x_initial,params,GG,9,4,GG2);
    subplot(339); title('orig status a');
    %plot_wavelet_decays_x_y_y2(x_orig,x_initial,338,1);
    
    %plot_wavelet_decays_x_y_y2(x_orig,x_initial,339,4);    
    %}
end
if disp
    subplot(339); title('orig status a');
end
diffiter=[];
fprintf('optimizing... \n')
normgrad=[];
for iter=1:max_iters
    figure(1)
    fprintf('## selfsim iter %5d ## ',iter);
    
    %wavelet_ratio = 0.95.^(iter-1);
    if iter>max_prior_iter
        wavelet_ratio=0;
    end
    
    % gradient calculation
    params = struct('use_scales',use_scales,'use_dirs',use_dirs,...
        'tot_dirs',tot_dirs,'desired_scales',desired_scales,'wavelet_ratio',wavelet_ratio,...
        'steprange',steprange,'tv_weight',tv_weight,'wname',wname);
    if wavelet_ratio>0
        %dL = calculate_selfsim_wavelet_grad(xv,GG,V,params);
        dL = calculate_selfsim_wavelet_grad_efficient(xv,[],V,params); % with wavelet kernels
    else
        dL = 0;
    end
    
    
    
    dL = dL*wavelet_ratio;
    %dt=0.01;
    if ~exist('dt','var')
        dt=0.01;
    end
    xv_im = reshape(xv,sz,sz);
    blur_term = -doconv( y - doconv(xv_im,b_kern) , rot90(b_kern,2) );
    
    tv = -gradTVcc(xv_im);
    %subplot(336); imagesc(tv),title('tv grad');
    % updates
    if xray
        mu=opts.mu;
    else
        %mu = linesearch_waveletopt(xv,length(xv),use_scales,dL,GG,V,C,use_dirs,dt,b_kern,y,blur_term,deblur_in_cost);
        dL = dL + dt*blur_term(:) + tv_weight*tv(:);
        mu = 1;%5e-3*max(xv(:))/max(1e-31,max(max(abs(dL(:)))));
    end
    normgrad(iter) = norm(dL);
    if disp
        subplot(338); hold off; plot(normgrad,'.-'); title('norm grad');
    end
        
    % deblur prior

    [step_sz, costs, steps] = waveletdeb_linesearch(xv_im,y,b_kern,dt,mu,dL,[],V,params,sz);
    if disp
        subplot(336); loglog(steps,costs,'.-'); title('cost function v step sz');
    end
   % [norm(mu*dL) norm(mu*dt*blur_term(:))]
    if deblur_in_cost
        xv = xv - step_sz*mu*dL; % deblur INSIDE line search 
    else
        xv = xv - mu*dL - dt*blur_term(:); % deblur OUTSIDE line search
    end
    
    
    fprintf('chosen step size: %1.3e. ',step_sz*mu);
    fprintf('norm grad: %1.2f. ',norm(dL));
    
    xv_im = reshape(xv,sz,sz);
    %{
    fprintf('edge tapering...\n')
    for a=1:4
        xv_im = edgetaper(xv_im,max(0.001,b_kern)); 
    end
    %}
    % %{
    if ~mod(iter,4) && opts.match_hist
        fprintf('matching histogram to deg img...\n');
        xv_im = histeq(xv_im,imhist(y));
    end
    %}
    xv = xv_im(:);
    %dLim = reshape(dL,sz,sz);
    if disp
        subplot(331); imshow(x_orig,[]); title('gt')
        subplot(332); maketitle('y',x_orig,y);
        subplot(333); maketitle('cur (wvlt)',x_orig,reshape(xv,sz,sz));
    end
    if steerable
        diffs_v = plot_steerable_wavelet_decays_x_y_y2(x_orig,reshape(xv,sz,sz),334,'h');
        diffs_h = plot_steerable_wavelet_decays_x_y_y2(x_orig,reshape(xv,sz,sz),335,'v');
        diffs_d = plot_steerable_wavelet_decays_x_y_y2(x_orig,reshape(xv,sz,sz),336,'a');
    else
        params=struct('n',n,'tot_dirs',tot_dirs,'use_dirs',use_dirs,'disp',display_curves,...
            'use_scales',use_scales,'do_y2',~model_straight_line,'y',y,'polyord',polyord,...
            'wname',wname,'nomeanreduce',opts.nomeanreduce,'model_straight_line',model_straight_line,...
            'y2',y2,'ylim',[-7 7],'desired_model',V);
        if ~mod(iter-1,1) % 20
            %diffs=plot_wavelet_decays_x_GG(x_orig,reshape(xv,sz,sz),params,GG,4,[1 2 3],GG2);
            if display_curves, figure(2), end
            diffs=plot_wavelet_decays_x_GG(x_orig,reshape(xv,sz,sz),params,[],1,use_dirs,[]);
            if display_curves, figure(1), end
            
        else
            if ~exist('diffs','var')
                diffs=10;
            end
        end
    end
    diffiter = [diffiter; [iter diffs(2)]];
    
    %figure(1); 
    if disp
        subplot(3,3,7); plot(diffiter(1:iter,2),'.-');
        title('decay diffs from y2 (only on dispcurv=1)')
    %subplot(337); imshow(xv_im-x_orig,[]); title('diff with gt')
        drawnow
    end
    diff_normgrad = diff(normgrad);
    if iter>1 && (norm(dL)<grad_thres || abs(diff_normgrad(end))<0.000000001)
        fprintf('grad norm or diff too low, breaking\n')
        break
    end
    if  (diffiter(end)<curve_thres) || ((mu < 1e-8)  && (iter > min_iters))
        fprintf('\nBREAKING, step size too low or selfs curve norm converged.\n')
        break
    end
    fprintf('\n')
end
fprintf('done\n')
end
%%%%%% aux functions %%%%%%
function l = logf(x,e)
if ~exist('e','var')
    e=0;
end
l = log(e+x);
end

%function res=doconv(x,b,estimate_blur)
%    res = imfilter(x,b,'conv','replicate');
%    if exist('estimate_blur','var')
%        res=res(1:end-1,1:end-1);
%    end
%end

%% get G matrices for steerable wavelets
function [GG,GG2,use_scales,use_dirs,tot_dirs]=get_G_matrices_steerable(sz,sz2,n,wname)

fname = sprintf('wsteermats_sz_%d_type_%s_n_%d.mat',sz,wname,n);
if exist(fname,'file')
    fprintf('loading mats from file\n')
    load(fname,'GG','GG2');
else
    fprintf('generating and saving wavelet matrices... ');
    [G,D,~] = generate_steerable_wavelet_matrices(sz,wname,n);
    [G2,D2,strs] = generate_steerable_wavelet_matrices(sz2,wname,n);

    tot_dirs = 4; % 4 orientations
    GG = cell(n,tot_dirs); % scale x direction
    GG2 = cell(n,tot_dirs); 
    %a=1;a2=1;
    a = G{1,strs.lp0};
    a2 = G2{1,strs.lp0};
    for i=1:size(GG,1)
        if i==1 % hp
            hp0 = G{i,strs.hp};
            g = {hp0 hp0 hp0 hp0};
            hp0 = G2{i,strs.hp};
            g2 = {hp0 hp0 hp0 hp0};
        else % bp
            g  = {G{i,strs.bp0}*a,   G{i,strs.bp1}*a,  G{i,strs.bp2}*a,  G{i,strs.bp3}*a};
            g2 = {G2{i,strs.bp0}*a2, G2{i,strs.bp1}*a2,G2{i,strs.bp2}*a2,G2{i,strs.bp3}*a2};
        end
        GG(i,:) = g;
        GG2(i,:) = g2;

        a = D{i}*(G{i,strs.lp}*a);
        a2 = D2{i}*(G2{i,strs.lp}*a2);
        drawnow
    end
    save(fname,'GG','GG2','-v7.3');
    fprintf('done\n');
    
    
end
tot_dirs=4; 
use_scales = 2:n;
use_dirs = 1:tot_dirs;
end