
function feats = get_PC_stats(x)

    orientations = linspace(0,180,12);
    wavelengths = 2:5;
    [congrus,Phi,M,m] = gabor_phases(x,wavelengths,orientations);
    %disp_multi(congrus);
    %Phi = max(0,Phi);
    M = max(0,M);
    lockurt = blockproc(M,[16 16],@(block) kurtosis(log(1+block.data(:))),'useparallel',false);
%    Mcols = im2col(M,[16 16])';
    %Mcols = log(1+Mcols);

%    Mcols = Mcols - mean(Mcols,2);
%    Mcols = Mcols ./ std(Mcols,[],2);
%    cov1 = nanvar(Mcols);
%    cov1(isnan(cov1))=0;

    %[c,p,a]=pca(Mcols);

    %pca_feats(ii,:) = a';
    %lockurt = blockproc(M,[16 16],@(block) var(block.data(:)));
    feats  = log(1+[nanmean(lockurt(:)) nanstd(lockurt(:))]); % kurtosis(log(1+M(:)));
    
    
end