%%%% learn a rule to match PC features with best SSIM 

%% flatten images and objective measurements
flat_res = {};
flat_PS = [];

best_per_exp = cell(1,length(exps_v));

for ii=1:length(exps_v)
    fprintf('=========== EXP %d/%d =============\n', ii, length(exps_v) );
    i = exps_v(ii);
    res_imgs_exp = res_iters_exp{i};
    res_best_rr = res_exp{i}{1};
    res_PS_rr = zeros(length(r2_thres_v)*iters,3);
    PS_rr = res_exp{i}{2}; %%%
    all_exp_res = {}; k=1;
    for rr=1:length(r2_thres_v)
        for it = 1:iters
            all_exp_res{k} = { res_imgs_exp{rr}{it}, r2_thres_v(rr), res_best_rr{rr}, i};
            %imshow(all_exp_res{k}{1}{2},[])
            %title(sprintf('P %1.2f S %1.2f',PS_rr{rr}(it,1:2)));
            %input('')
            res_PS_rr(k,:) = PS_rr{rr}(it,:);
            k=k+1;
        end
    end 
    flat_res = [flat_res all_exp_res];
    flat_PS = [flat_PS; res_PS_rr];
end
% now flat_res contains all learning exps and flat_PS contains all
% respective PSNR and SSIM figures.

%% get PC stats from each image
flat_features = zeros(length(flat_res),5);
flat_targets = flat_PS(:,1); % 2 is SSIM
for i=1:length(flat_res), fprintf('.'), end
fprintf('\n\n');
border=20;
parfor i=1:length(flat_res)
    fprintf('\b^\n');
    im = flat_res{i}{1}{2};
    %im = min(1,max(0,im));
    cropped = im(border:end-border+1,border:end-border+1);
    pc_stats = get_PC_stats(cropped);
    %cropped = im(border:end-border+1,border:end-border+1);
    other_stats=[];
    other_stats(1) = -entropy((randn(size(cropped))*std(cropped(:))+mean(cropped(:)))) + ...
        entropy(cropped);
    [h,~,R2]=estimate_h_2d_inc(cropped);
    other_stats(2:3) = [h R2];%log(1-R2);
    stats = [pc_stats other_stats];
    flat_features(i,:)=stats;
    %flat_features = [flat_features; pc_stats];
end

%% divide to train and test
rng(0);
learn_percent = 0.2;
exp_rand_idx = randperm(length(exps_v));
learn_per = round(learn_percent*length(exps_v));
learn_exp_idx = exp_rand_idx(1:learn_per);
test_exp_idx = exp_rand_idx(learn_per+1:end);

res_per_exp = size(flat_features,1)/length(exps_v);
res_exp_v = kron(1:length(exps_v),ones(1,res_per_exp));

learn_flat_idx = get_exp_idcs(res_exp_v,learn_exp_idx);
test_flat_idx = get_exp_idcs(res_exp_v,test_exp_idx);

learn_features = flat_features(learn_flat_idx,:);
learn_targets = flat_targets(learn_flat_idx);
test_features = flat_features(test_flat_idx,:);
test_targets = flat_targets(test_flat_idx);



%% train classifier to peform regression PC->obj (SSIM)
SSIMnet = train_net_for_best_img_decision(learn_features,learn_targets);

%
%%{
% now, choose best images from each experiment according to the network
best_test_exp = cell(1,length(test_exp_idx));
for i=1:length(test_exp_idx)
    i/length(test_exp_idx)
    range_cur_exp = get_exp_idcs(res_exp_v,test_exp_idx(i));
    features = flat_features(range_cur_exp,:);
    res_ssim = SSIMnet(features');
    [max_ssim,best_idx]=max(res_ssim);
    %[mean(res_ssim) max_ssim]
    best_flat_idx = best_idx + find(range_cur_exp==1,1,'first')-1;
    
    best_est = flat_res{best_flat_idx}{1}{2};
    best_ker = flat_res{best_flat_idx}{1}{1};
    best_r2 = flat_res{best_flat_idx}{2};
    
    ii = test_exp_idx(i);
    x = exps(ii).orig;
    [x1,est1,best_circshift] = find_best_circshift2(x,best_est);
    %subplot(211); imagesc(best_est);
    %subplot(212); imagesc(best_circshift);
    %input('')
    best_ps = maketitle_d('',x1,best_circshift,border,0);
    
    best_test_exp{i} = {best_circshift, best_ker, best_r2, best_ps};
    
end
%
best_per_exp = cell(1,length(exps_v));
for i=1:length(test_exp_idx)
    best_per_exp{test_exp_idx(i)}=best_test_exp{i};
end
%%
