README
======
This is a supplementary code for the paper:
Ido Zachevsky and Yehoshua Zeevi, "Blind deblurring of natural stochastic textures using an anisotropic fractal model and phase retrieval algorithm", submitted to IEEE Transcations on Image Processing (2017)

We provide MATLAB codes to replicate the experiments described in the paper.

Contents:
1. Modified Goldstein and Fattal code, adapted for our algorithm (./FattalDeblur/)
2. Modified GESPAR algorithm, adapted for blur filter phase retrieval (./gespar/)
3. Texture blind deblurring components:
   a. filter design (hp_filter_design.m)
   b. wavelet post processing (selfsim_wavelet_postproc.m)
   c. learning based ssim predictor (learning_based_best_ssim_predictor.m)
4. Some auxiliary files for generating comparisons. These require Levin et al.'s and Michaeli and Irani's codes to be provided. (state_of_the_art_algorithms_evaluation.m)
5. Textures used in the paper in ./textures
6. Other auxiliary files.

The main file is "experiments.m". Running the code performs blind deconvolution for this image, up to the learning based ssim predictor which requires a set of textures to be used for learning.





