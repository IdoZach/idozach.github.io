function [PS]=maketitle_d(s,x,y,d,disp)
if ~exist('disp','var')
    disp=1;
end
if ~exist('d','var')
    d=3;
end
x = x(d:end-d+1,d:end-d+1);
y = y(d:end-d+1,d:end-d+1);
PSNR1 = @(x,y) PSNR(x,y);
ssim1 = @(x,y) ssim(x,y);

PS.P=PSNR1(mat2gray(x),mat2gray(y));
PS.S=ssim1(mat2gray(x),mat2gray(y));
if disp
    imshow(y,[]);
    title(sprintf('%s,P%1.2f S%1.3f',...
        s,PS.P,PS.S));
end
end