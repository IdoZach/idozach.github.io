function Dy = D_y(img,vert,hor,dy);
% backward derivative
Dy=[img(:,2:vert) img(:,hor)]-img;
Dy = Dy/dy;
%Dy = padarray(Dy(2:end-1,2:end-1),[1 1],'both','replicate');