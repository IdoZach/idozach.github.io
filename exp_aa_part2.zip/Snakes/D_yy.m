function Dyy = D_yy(img,vert,hor,dy);
% second order derivative - by performing forward-backward-derivatives
Dyy = D_y(img,vert,hor,dy);
Dyy = D_y2(Dyy,vert,hor,dy);
%Dyy = padarray(Dyy(3:end-2,3:end-2),[2 2],'both','replicate');
