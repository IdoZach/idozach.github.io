
function c = initial_contour(m,n);
for k = 7:n-7;   %   46 cells   3:n-3;  
    c(k-6,:) = [7 k];       %c(k-2,:) = [3 k];
end
for  k = 8:m-8  % 44 cells   k =  4:m-4;  
           c(n-20+k,:) = [ k (n-7)];          % c(n-8+k,:) = [ k (n-3)];  
end
for  k = 8:n-6;              %%%%%%%%%%% k:2 -> 4 n-1 -> n-2       4:n-2; 
         c(n-2+m-3+k-10-20,:) = [(m-7) (n-k+1)];       %c(n-2+m-3+k-10,:) = [(m-3) (n-k+1)]; 
end
for k = 9:m-7;               %5:m-3;  
         c(2*(n-2)+m-3+k-3-11-28,:) = [(m-k+1) 7];  %   c(2*(n-2)+m-3+k-3-11,:) = [(m-k+1) 3];
end
z = 1;
    