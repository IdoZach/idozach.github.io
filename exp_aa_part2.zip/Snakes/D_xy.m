function Dxy = D_xy(img,vert,hor,dx,dy)
% mixed derivative - averaging all possibilities for increased stability

%{
img1 = padarray(img,[1 1],'both','replicate');
N=size(img1,1);
%m = 2:N-1;
b = 1:N-2;
f = 3:N;
Dxy=img1(f,f) + img1(b,b) - img1(f,b) - img1(b,f);
%}

Dxy = D_x2(img,vert,hor,dx);
Dxy1 = D_y(Dxy,vert,hor,dy);

Dxy = D_x(img,vert,hor,dx);
Dxy2 = D_y2(Dxy,vert,hor,dy);

Dxy = D_x(img,vert,hor,dx);
Dxy3 = D_y(Dxy,vert,hor,dy);

Dxy = D_x2(img,vert,hor,dx);
Dxy4 = D_y2(Dxy,vert,hor,dy);

Dxy = 0.25*(Dxy1+Dxy2+Dxy3+Dxy4);

%Dxy = padarray(Dxy(3:end-2,3:end-2),[2 2],'both','replicate');