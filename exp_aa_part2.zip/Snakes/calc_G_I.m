%% calc_G_I(img,m,n): Calculating weight function (stopping criteria) for
%% the evolution step. 
%% Private function by Eli Appleboim.
%% m and n are parameters of the image resolution. 
%% calculation are made after the image is smoothed via Gaussian
%% filtering.

function [G,dg_x,dg_y] = calc_G_I(img,m,n);

dx = 1;
dy = 1;
% h = fspecial('gaussian',[3 3],1);
% fil_img = imfilter(img,h,'same');
Dimg_x = 255*D_x2(img,m,n,dx);    % calculating image derivative w.r.t X axis.
Dimg_y = 255*D_y2(img,m,n,dy);    % calculating image derivative w.r.t Y axis.
a=2;
G = 1 ./ (1 + abs(Dimg_x).^a + abs(Dimg_y).^a);
dg_x = D_x(G,m,n,dx);
dg_y = D_y(G,m,n,dx);