function Dx = D_x2(img,vert,hor,dx)
% forward derivative
Dx=-[img(1,:); img(1:vert-1,:)]+img;
Dx=Dx/dx;
%Dx = padarray(Dx(2:end-1,2:end-1),[1 1],'both','replicate');