%% evolve surface (U,G,dg_x,dg_y): surface, initialized as a signed distance
%% map, is evolved according to the CURVATURE FLOW of the zero level set
%% curve.
%% Private function by Eli Appleboim.

function U = evolve_surface(U,G,dg_x,dg_y)
[dim1 dim2] = size(U);
dx = 0.8;
dy = dx;
dt = 1/(2*(1 + dx^2 + dy^2));
%dt=dt*3;

% First derivatives
%DU_x1 = D_x(U,dim1,dim2,dx);
%DU_y1 = D_y(U,dim1,dim2,dy);

DU_x = D_x2(U,dim1,dim2,dx);
DU_y = D_y2(U,dim1,dim2,dy);

% Second derivatives.
DU_xx = D_xx(U,dim1,dim2,dx);
DU_yy = D_yy(U,dim1,dim2,dy);
DU_xy = D_xy(U,dim1,dim2,dx,dy);

eps=0.01; % regularization
term1 = DU_xx.*(DU_y.^2) + DU_yy.*DU_x.^2 - 2*DU_xy.*DU_x.*DU_y;
term1 = term1 ./ (eps+abs(DU_x).^2+abs(DU_y).^2);
a=2;
% this works with abs() for some reason...
term2 = abs(dg_x .* DU_x + dg_y .* DU_y) ./ (eps+abs(DU_x).^a + abs(DU_y).^a).^(1/2);

U = U + dt*(G.*term1 + term2);

