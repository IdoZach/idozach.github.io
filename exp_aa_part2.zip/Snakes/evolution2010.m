%%  Evolution: evolution of a curve according to "geodesic active contoures" method.
%%  Private function by Eli Appleboim. 
%%  Distance map is precomuted !!! and uploaded during process in order to save run time. 
%% Important: Distance map is NOT updated for time saving consideration.
%% Narrow band fast marching shell by applied in the future to correct this. 


close all;
clear all;


%%   When run on "occludede" this should be applyed !!!!!!
img = double(imread('occluded.jpg'))/255; 
img = imcrop(img(:,:,1),[20 00 110 100]);
img = imresize(img(:,:,1),[65 65]);
%img = mat2gray(img.^0.25);
imshow(img,[]);
update_step = 5000;                 % each update _step iteration level zero set  will be computed and displayed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%surface_generation

%% On "Eight" apply this !!!!!!
sz=65;
%surface_generation
sz=65;
img = double(imread('eight2.tif'))/256;
img = img(:,:,1);
%img = awgn(img,20);
img = imresize(img,0.3);
stx=10;sty=10;
img = img(stx:stx+sz-1,sty:sty+sz-1);
addn = randn(size(img))>1.5;
%img(addn)=0.3;
update_step = 5000;                 % each update _step iteration level zero set  will be computed and displayed
%%
%%%%%%%%%%%%%%%%
imshow(img,[]);
h = fspecial('gaussian',[3 3],1);
fil_img = imfilter(img,h,'same');
%h = fspecial('gaussian',[3 3],1);
%fil_img = imfilter(img,h,'same');
load 'initial_map.mat';

iter = 0;
[dim1 dim2] = size(img);
C = initial_contour(dim1,dim2); % [(((dim1-1)/2)+1) (((dim1-1)/2)+1)];    
[G_I,DG_x,DG_y] = calc_G_I(fil_img,dim1,dim2);          % Calculate image characteristics and stopp function
%[G_I2,DG_x2,DG_y2] = calc_G_I(fil_img2,dim1,dim2);          % Calculate image characteristics and stopp function
G_C = ones(size(C,1),1);                                                % restriction of G on the level-set curve C.
%[G_I,DG_x,DG_y] = calc_G_I(img,dim1,dim2);          % Calculate image characteristics and stopp function
%G_C = ones(size(C,1),1);                                                % restriction of G on the level-set curve C.

% while mean(G_C) > 0.1
%     U_x_y = evolve_surface(U_x_y,G_I,DG_x,DG_y);
%     if mod(iter,update_step) == 0
%         C = round(contourc(U_x_y,[0 0]))';                   % C is the zero level set curve.
%         [C,num_comp] = actual_c(C);                               % Matlab function contourc sometimes gives multiple points that should be taken only once for the curve C.
%         figure;imshow(img);title([ 'Iteration =  '  num2str(iter)]);
%         for i = 1:size(num_comp,1),
%             x = C(num_comp(i,1):num_comp(i,2),1); y = C(num_comp(i,1):num_comp(i,2),2);
%             line(x,y);                                                              % Drawing C on the screen.
%         end
%         pause(1);
%     end
%     iter = iter+1;
% end

%U_x_y=U_x_y*0;
%for i=1:length(C)
%    U_x_y(C(i,1),C(i,2))=1;
%end
prev_area=0;
while max(G_C) > 0.1
    %if iter>15000
    %    G_I=G_I2;
    %    DG_x=DG_x2;
    %    DG_y=DG_y2;
    %end
    Uprev = U_x_y;
    U_x_y = evolve_surface(U_x_y,G_I,DG_x,DG_y);

    %U_x_y = padarray(U_x_y(2:end-1,2:end-1),[1 1],'both','symmetric');
    %U_x_y = edgetaper(U_x_y,fspecial('gaussian',5,2));
    cur_area = sum(sum(signed_U(U_x_y,C,dim1,dim2,1)<0));
    %if mod(iter,update_step) == 0
    cond = cur_area - prev_area > 300;
    if ( cond || (mod(iter,update_step) == 0))% && false
        prev_area = cur_area;
        C = round(contourc(U_x_y,[0 0]))';                % C is the zero level set curve.
        [C,num_comp] = actual_c(C);                               % Matlab function contourc sometimes gives multiple points that should be taken only once for the curve C.
        %imshow(img,[]); hold on;
        %title([ 'Iteration =  '  num2str(iter)]); 
        %for i = 1:size(num_comp,1),
        %    x = C(num_comp(i,1):num_comp(i,2),1); y = C(num_comp(i,1):num_comp(i,2),2);
        %    line(x,y);                                                              % Drawing C on the screen.
        %end
        %plot(C(:,1),C(:,2),'r');
        %imshow(U_x_y==0,[]);
        %drawnow;
        %hold off;
        subplot(221); imshow(log(abs(U_x_y)),[]); title(['U before ' num2str(iter)]); drawnow;
        fprintf('Re-calculating distance map...');
        U_x_y = fast_marching(C,dim1,dim2);
        subplot(222); imshow(U_x_y,[]); title(['U after ' num2str(iter)]); drawnow;
        %hold off; plot(C(:,1),C(:,2),'o')
        
        U_x_y = signed_U(U_x_y,C,dim1,dim2,1);
        fprintf('done.\n');
        %subplot(222); imshow(U_x_y,[]);
        drawnow; 
    end
    if mod(iter,1)==0
            a = round(contourc(U_x_y,[0 0]));
            %subplot(211); 
            %plot(a(1,:),a(2,:),'o');
            %imshow(abs(U_x_y)<0.5 ,[]);
            subplot(224); imshow(log(abs(U_x_y)),[]); title(num2str(iter));
            %hold on; plot(a(1,:),a(2,:),'o');
            subplot(223); imshow(fil_img,[]); 
            hold on; plot(a(1,:),a(2,:),'.');
            title(num2str(iter));
            drawnow
    end
    %C = round(contourc(U_x_y,[0 0]))';                  % C is the zero level set curve.
%    [C1,num_comp] = actual_c(C);
    
%    for i = 1:size(num_comp,1),
%            x = C(num_comp(i,1):num_comp(i,2),1); y = C(num_comp(i,1):num_comp(i,2),2);
%    end
    iter = iter+1;
%    for i = 1:size(x,1),
%           G_C1(i) = G_I(x(i),y(i));
%    end
    %G_C = G_C1(1:size(x,1));
    
%     SVal = find(G_C < 0.1);
%     Stop = double(size(SVal))/double(size(G_C)) ;
end

