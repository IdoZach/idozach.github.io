
function S_U = signed_U(U,c,m,n,iter);
if iter == 0
    mask = zeros(m,n);
    mask(8:m-8,8:m-8) = 1;
    %mask(4:m-4,4:m-4) = 1;
else
    x = c(:,1);
    y = c(:,2);
    
    %figure;
    %v = fill(x,y,'k');
    % h = axes('XLim',[1 m],'YLim',[1 n]);
    % set(v,'parent',h);
    % fr = getframe;
    % im = imresize(fr.cdata(:,:,1),[m n]);
    % close(figure);
    mask = zeros(m,n);
    for i=1:length(x)
        mask(x(i),y(i)) = 1;
    end
    %mask(x,y) = 1;
    im = imfill(mask);
    mask = double(im);
    %subplot(121); plot(x,y,'o');
    %subplot(122);     imshow(mask,[]);pause(1);drawnow;
     %mask(1,26) = 0; mask(1,31) = 0; mask(51,26) = 0; mask(51,31) = 0; mask(26,1) = 0; mask(31,1) = 0; mask(26,51) = 0; mask(31,51) = 0; 
end
S_U = U - 2*(U .* mask);
