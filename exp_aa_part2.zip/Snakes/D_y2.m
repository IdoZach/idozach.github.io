function Dy = D_y2(img,vert,hor,dy);
% second order derivative - by performing forward-backward-derivatives
Dy=-[img(:,1) img(:,1:hor-1)]+img;
Dy=Dy/dy;
  
