%% fast marching(c,m,n): Building distance map according to "fast marching"
%% method.
%% Private function by Eli Appleboim.

function dist_map = fast_marching(c,m,n);

[Alive,Near,size_Far,Phi,Phi_near] = initialize(c,m,n);

dist_map1  =  marching_step(Alive,Near,size_Far,Phi,Phi_near,n,m);
dist_map = dist_map1(2:m+1,2:n+1);

