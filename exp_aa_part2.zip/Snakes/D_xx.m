function Dxx = D_xx(img,vert,hor,dx)
% second order derivative - by performing forward-backward-derivatives
Dxx = D_x(img,vert,hor,dx);
Dxx = D_x2(Dxx,vert,hor,dx);
%Dxx = padarray(Dxx(3:end-2,3:end-2),[2 2],'both','replicate');