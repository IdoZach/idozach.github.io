% Evolution: evolution of a curve according to "geodesic active contoures" method.
% Private function by Eli Appleboim. 
% Distance map is precomuted !!! and uploaded during process in order to save run time. 
% Important: Distance map is NOT updated for time saving consideration.
% Narrow band fast marching shell by applied in the future to correct this. 
% Updated 10.2013 - Ido Z. (ido at tx)
%% 
close all;
clear all;

%% First image - two figures.
sz=65; % image size
img = double(imread('occluded.jpg'))/255; 
img = imcrop(img(:,:,1),[20 00 110 100]);
img = imresize(img(:,:,1),[65 65]);
imshow(img,[]); title('Two figures');

%% Second image - coins.
sz=65; % image size
img = double(imread('eight2.tif'))/256; 
img = img(:,:,1); img = imresize(img,0.3); % choose a segment
stx=10;sty=10; img = img(stx:stx+sz-1,sty:sty+sz-1);

%% Surface evolution

% If size is not the default, run sufrace_generation to obtain an initial
% map.

update_step = 5000;                 % each update _step iteration level zero set  will be computed and displayed
%%%%%%%%%%%%%%%%
imshow(img,[]); % show image
h = fspecial('gaussian',[3 3],1); % initial blur
fil_img = imfilter(img,h,'same');
load 'initial_map.mat';

iter = 0;
[dim1 dim2] = size(img);
C = initial_contour(dim1,dim2); % Create the initial contour
[G_I,DG_x,DG_y] = calc_G_I(fil_img,dim1,dim2); % compute diffusivity function and its derivatives

%U_x_y=U_x_y*0;
%for i=1:length(C)
%    U_x_y(C(i,1),C(i,2))=1;
%end
display_iter = 10; % display each X iterations
use_distance_map = false; % change when required
prev_area=0;
prev_area_break = 0;
area_change_th = -1;
break_cond = 0;
while ~break_cond || iter<100
    % evolve the surface according to the map U_x_y and expected boundaries (G and derivatives)
    U_x_y = evolve_surface(U_x_y,G_I,DG_x,DG_y);

    cur_area = sum(sum(signed_U(U_x_y,C,dim1,dim2,1)<0));
    cond_update = cur_area - prev_area > 300; % do not compute distance map each time, only after sufficient change in the map
    
    if ( cond_update || (mod(iter,update_step) == 0)) && use_distance_map
        prev_area = cur_area;
        C = round(contourc(U_x_y,[0 0]))'; % C is the zero level set curve.
        [C,num_comp] = actual_c(C);  % Matlab function contourc sometimes gives multiple points that should be taken only once for the curve C.

        % display the current distance map
        subplot(221); imshow(log(abs(U_x_y)),[]); title(['U before ' num2str(iter)]); drawnow;
        
        % Re-calculate distance map
        fprintf('Re-calculating distance map...');
        U_x_y = fast_marching(C,dim1,dim2);
        subplot(222); imshow(U_x_y,[]); title(['U after ' num2str(iter)]); drawnow;
        U_x_y = signed_U(U_x_y,C,dim1,dim2,1);
        fprintf('done.\n');
        drawnow; 
    end
    if mod(iter,display_iter)==0
            a = round(contourc(U_x_y,[0 0]));
            subplot(224); imshow(log(abs(U_x_y)),[]); title(num2str(iter));
            subplot(223); imshow(fil_img,[]); 
            hold on; plot(a(1,:),a(2,:),'.');
            title(num2str(iter));
            drawnow
    end
    iter = iter+1;
    
    if abs(cur_area - prev_area_break) < area_change_th 
        break_cond = 1;
    end
    prev_area_break = cur_area;
end

