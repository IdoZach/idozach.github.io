

function [A,N,S,P,P_N] = initialize(c,m,n);

% initialize dist. map to infinity and F to 1
P = ones(m+2,n+2); 
P = inf*P;        
F = ones(m+2,n+2);
for k = 1:m+2;
    top(k,:) = [1 k];
    bot(k,:) = [m+2 k];
end
for k = 1:n+2;
    lft(k,:) = [k 1];
    rit(k,:) = [k n+2];
end
d = unique(c,'rows');
S = (m)*(n) - size(d,1);                                                % initialize the size of Far_points set;
%%%%%%%%%%%%%
% Initialize Alive_points and Near_points:     end_N is the dinamic index of Near-points set.
end_N = 1;
A = c+1;
N(1,:) = [0 0];
P_N(end_N) = 0; 
%%%%%%%%%%%%%
for j = 1:size(A,1);
    x = A(j,1);
    y = A(j,2);
    P(x,y) = 0;
    F(x,y) = 0;
    
    neibr = [x-1 y; x y-1;x+1 y;x y+1];                                     % Four neighbors of current Alive point
    % Find which of these neighbors ia not an Alive point or is already  Near point.
    for i = 1:4
    if  (  (ismember(neibr(i,:),top,'rows') == 0) && (ismember(neibr(i,:),bot,'rows') == 0) && (ismember(neibr(i,:),lft,'rows') == 0) && (ismember(neibr(i,:),rit,'rows') == 0))
        if  (  (ismember(neibr(i,:),A,'rows') == 0) && (ismember(neibr(i,:),N,'rows') == 0))
            N(end_N,:) = neibr(i,:); 
            P(N(end_N,1),N(end_N,2)) = F(N(end_N,1),N(end_N,2));
            P_N(end_N) = P(N(end_N,1),N(end_N,2));
            end_N = end_N + 1;
            S = S - 1;
        end
    end   
end
end
init = 1;
%v = intersect(find(ismember(neibr,A,'rows')==0), find(ismember(neibr,N,'rows')==0));
    % Those that are NEW Near_points are added to Near_points set and their value of dist. is updated.  
    %for k = 1:size(v);
