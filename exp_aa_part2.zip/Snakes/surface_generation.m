%    02.09 
%clear all;
iter = 0;
img = double(imread('occluded.jpg'))/255; 
img = imresize(img(:,:,1),[sz sz]);

[dim1 dim2] = size(img);
C = initial_contour(dim1,dim2); % [(((dim1-1)/2)+1) (((dim1-1)/2)+1)]; 
x = C(:,1); y = C(:,2);
imshow(img);line(x,y);

U_x_y = fast_marching(C,dim1,dim2);
U_x_y = signed_U(U_x_y,C,dim1,dim2,iter);
save 'initial_map.mat' U_x_y C;