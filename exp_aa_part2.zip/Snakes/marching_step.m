
function dist  =  marching_step(A,N,S,P,P_N,n,m);

F = ones(m+2,n+2);
for k = 1:m+2;
    top(k,:) = [1 k];
    bot(k,:) = [m+2 k];
end
for k = 1:n+2;
    lft(k,:) = [k 1];
    rit(k,:) = [k n+2];
end

while S > 0
    end_N  = size(N,1);
    end_A  = size(A,1);
    [sorted_P_N indices] = sort(P_N); 
for j = 1:end_N;
    sorted_N(j,:) = N(indices(j),:);
end
N = sorted_N(1:end_N,:);
if ( (ismember(N(1,:),top,'rows') == 0) && (ismember(N(1,:),bot,'rows') == 0) && (ismember(N(1,:),lft,'rows') == 0) && (ismember(N(1,:),rit,'rows') == 0))
end_A = end_A + 1;
A(end_A,:) = N(1,:);
x = A(end_A,1);
y = A(end_A,2);
neibr = [x-1 y; x y-1;x+1 y;x y+1]; 
    for i = 1:4
    if  ( (ismember(neibr(i,:),A,'rows') == 0) && (ismember(neibr(i,:),top,'rows') == 0) && (ismember(neibr(i,:),bot,'rows') == 0) && (ismember(neibr(i,:),lft,'rows') == 0) && (ismember(neibr(i,:),rit,'rows') == 0))
        Phi_x = min(P(neibr(i,1),neibr(i,2)-1),P(neibr(i,1),neibr(i,2)+1));
        Phi_y = min(P(neibr(i,1)-1,neibr(i,2)),P(neibr(i,1)+1,neibr(i,2)));
        if abs(Phi_x - Phi_y) < F(neibr(i,1),neibr(i,2))
            t = 0.5*(Phi_x + Phi_y +sqrt( 2*(F(neibr(i,1),neibr(i,2))^2) - (Phi_x - Phi_y)^2));
        else
            t = min(Phi_x,Phi_y) + F(neibr(i,1),neibr(i,2));
        end
        P(neibr(i,1),neibr(i,2)) = min(P(neibr(i,1),neibr(i,2)),t);
        %P(neibr(i,1)) = min(P(neibr(i,:)),t);
        if  ismember(neibr(i,:),N,'rows') == 0
            end_N = end_N + 1;
            N(end_N,:) = neibr(i,:); 
            %val = P(N(end_N,1),N(end_N,2));
            sorted_P_N(end_N) = P(N(end_N,1),N(end_N,2));
            S = S-1;
        end
    end
end
end
new_N = N(2:end_N,:);
N = new_N;
new_P_N = sorted_P_N(2:end_N);
P_N = new_P_N;
P(1,:) = P(2,:); 
P(n+2,:) = P(n+1,:);
P(:,1) = P(:,2);
P(:,m+2) = P(:,m+1);
end
step = 1;
dist = P;   

