
function [ct,comp1] = actual_c(c)
if c(1,2) < (size(c,1) - 1);
    j =1; comp = 1; s = 0;
    while j < size(c,1);
        d = c(j,2);
        c1 = c((j+1):(j+d),:);
        c2 = unique(c1,'rows');
        if size(c2,1) > 49
            ct(s+1:s+d,:) = c((j+1):(j+d),:);
            comp1(comp,:) = [s+1 s+d];
            s = s+d;
            comp = comp+1;
        end
        j = j+d+1;
    end 
else
    ct = c(2:size(c,1),:);
    comp1 = [1 size(c,1)-1];
end
