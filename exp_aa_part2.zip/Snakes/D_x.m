function Dx = D_x(img,vert,hor,dx)
% backward derivative
Dx=[img(2:vert,:); img(hor,:)]-img;
Dx = Dx/dx;
