% derivative testing

a = imread('cameraman.tif');
N=128;

a = imresize(double(a),[N N]);
a = a*0;
a(10:end-10,10:end-10) = 1;
a(20:end-20,20:end-20) = 0;
axf = D_x(a,N,N,1);
axb = D_x2(a,N,N,1);
ayf = D_y(a,N,N,1);
ayb = D_y2(a,N,N,1);
axx = D_xx(a,N,N,1);
axy = D_xy(a,N,N,1,1);
ayy = D_yy(a,N,N,1);

close all;
figure; imshow(a,[]);
cur = axf; figure; imshow(cur,[]); 
cur = axb; figure; imshow(cur,[]);
%%
close all;
figure; imshow(a,[]);
cur = ayf; figure; imshow(cur,[]);
cur = ayb; figure; imshow(cur,[]);

%%
close all;
figure; imshow(a,[]);
cur = axx; figure; imshow(cur,[]);
cur = ayy; figure; imshow(cur,[]); 

%%
close all;
axy = D_xy(a,N,N,1,1);
cur = axy; figure; imshow(cur,[]); figure; imshow(a,[]);

