function O = beltrami(rgb_image,iterations,beta,islog)
%% beltrami(rgb_image,iterations,beta)
%% private function (Roni Kimmel's version with adaptations by Guy Gilboa)
if ~exist('islog','var')
    islog=0;
end
A=rgb_image;
if ~islog
    O=double(A);   % work in RGB domain
else
    O=log2(double(abs(A))+1);   % work in the log domain
end
R = double(O(:,:,1)); G = double(O(:,:,2)); B = double(O(:,:,3));
%dt =  0.21*0.01;   %% good for all beta >= 0.01
dt=0.2;

if (beta<1)
   dt =  0.2*beta;   
end
a=1;
for p = 1:iterations,
   Rx = a*Dmx(R); Gx = Dmx(G); Bx = Dmx(B);
   Ry = a*Dmy(R); Gy = Dmy(G); By = Dmy(B);
   
   g11 = beta+Rx.^2+Gx.^2+Bx.^2;
   g12 = Rx.*Ry+Gx.*Gy+Bx.*By;
   g22 = beta+Ry.^2+Gy.^2+By.^2;
   gm05 = (g11.*g22 - g12.^2).^(-0.5);    % gm05 = 1/sqrt(g)
   
   R = belt(dt,R,Rx,Ry,gm05,g11,g12,g22);
   G = belt(dt,G,Gx,Gy,gm05,g11,g12,g22);
   B = belt(dt,B,Bx,By,gm05,g11,g12,g22);
   
end  % for p
if islog
    O(:,:,1) = (2.^R)-1; O(:,:,2)=(2.^G)-1; O(:,:,3)=(2.^B)-1;
else
    O(:,:,1) = R; O(:,:,2)=G; O(:,:,3)=B;
end
%O=uint8(O);

%%%%%%%%%%%%%%%%%%%%%%%%%%

% res = R+dt*DgR    ,  Dg = beltrami operator
function res = belt(dt,R,Rx,Ry,gm05,g11,g12,g22)
	res = gm05.*(Dpx(gm05.*(g22.*Rx-g12.*Ry))+Dpy(gm05.*(-g12.*Rx+g11.*Ry)));
   res = R+dt*res;
   res = max(min(res,8),0);
   %%%%% end function
   
%%%%%%%%%%%%%%%%%%%%%%%%%%% Backward derivatives
function f = Dmx(P)
	f = P-P([1 1:end-1],:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%
function f = Dmy(P)
	f = (Dmx(P'))';
%%%%%%%%%%%%%%%%%%%%%%%%%%% Forward derivatives
function f = Dpx(P)
	f = P([2:end end],:)-P;
%%%%%%%%%%%%%%%%%%%%%%%%%%%
function f = Dpy(P)
	f = (Dpx(P'))';


   