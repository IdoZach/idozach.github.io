% Gradient descent deblurring without regularization, i.z. 

filt_sz = 5; % size of deblurring filter
maxiter = 1000; 
eps = 0.0002; % this is the minimal CHANGE between gradient norms in subsequent iterations
alpha = 2; % gain of gradient norm for gradient descent scheme

im.orig = double(imread('cameraman.tif')); % some original image
im.orig = rgb2gray(double(imread('temp.jpg'))/256); % some original image

sigma = (max(im.orig(:))-min(im.orig(:)))/100; % noise std (sqrt of variance)

blur_kernel = fspecial('average',filt_sz);
im.blur = imfilter(im.orig,blur_kernel,'symmetric'); % create blurred image
im.blur = im.blur + sigma*randn(size(im.blur));

%im.blur = im.orig; % real blurred image

im.deblurred = im.blur; % initial guess

mse.orig_blur = norm(im.blur - im.orig); % original MSE
mse_v = zeros(1,maxiter);

% display
subplot(221); imshow(im.orig,[]); title('orig image');
subplot(222); imshow(im.blur,[]); title(sprintf('blurred image, mse %1.2f',mse.orig_blur));

for i=1:maxiter
    temp_1 = im.blur - imfilter(im.deblurred,blur_kernel,'symmetric'); % calculate gradient
    grad = imfilter(temp_1,blur_kernel,'symmetric');

    im.deblurred = im.deblurred + alpha*grad; % perform gradient descent
    
    mse.deblurred = norm(im.deblurred - im.orig); % calculate MSE
    mse_v(i) = mse.deblurred;
    
    % display
    subplot(223); imshow(im.deblurred,[]); 
    title(sprintf('deblurred image, mse %1.2f',mse.deblurred));
    subplot(224); plot(mse_v(1:i)); title('MSE v. iterations');
    drawnow;
    
    % check if the gradient hasn't changed too much (result is pretty
    % 'stable'). This is INSTEAD of checking the norm of the gradient
    % itself which might take a long time.
    if i>1
        if abs(mse_v(i)-mse_v(i-1)) < eps 
            fprintf('Reached minimal change in grad norm, exiting...\n');
            break
        end
    end
end