function res = PSNR(orig,deg)
res = 10*log10(max(orig(:))^2 / (1/numel(deg)*sum( (orig(:)-deg(:)).^2 ) ) );
end
