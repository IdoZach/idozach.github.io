% PSNR2sig
% input:    PSNR - desired Peak signal-to-noise ratio value
%           maxPixelValue - maximal pixel value of the clean image, where
%           its minimal value is 0.
% output:   Standard deviation of Gaussian noise, can be used as follows:
%           y = x + sig*randn(size(x));

function sig = PSNR2sig(PSNR, maxPixelValue)
sig = 10^(-PSNR/20)*maxPixelValue;
end